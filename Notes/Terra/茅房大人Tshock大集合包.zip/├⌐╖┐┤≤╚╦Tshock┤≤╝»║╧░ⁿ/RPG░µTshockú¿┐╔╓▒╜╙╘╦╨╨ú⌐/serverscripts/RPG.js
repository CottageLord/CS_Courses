﻿//显示名：显示名,就是玩家看到的/转职 xxx的那个名字
//升级命令：升级命令就是升级的时候执行的命令，不需要管权限
//升级物品：升级物品就是升级的时候获得的物品
var rankingList = {
	"neo": {
		"name": "neo",
		"显示名": "neo",
		"parentgroup": undefined,
		"group": "neo",
		"升级命令": [],
		"升级物品": [],
		"cost": "0"
	},
	"default": {
		"name": "default",
		"显示名": "0级",
		"parentgroup": "neo",
		"group": "default",
		"升级命令": [],
		"升级物品": [],
		"cost": "0"
	},
	"Lv1": {
		"name": "Lv1",
		"显示名": "1级",
		"parentgroup": "default",
		"group": "Lv1",
		"升级命令": [],
		"升级物品": [],
		"cost": "8000"
	},
	"Lv2": {
		"name": "Lv2",
		"显示名": "2级",
		"parentgroup": "Lv1",
		"group": "Lv2",
		"升级命令": [],
		"升级物品": [],
		"cost": "20000"
	},
	"近战": {
		"name": "近战",
		"显示名": "战士",
		"parentgroup": "Lv2",
		"group": "近战Lv3",
		"升级命令": [],
		"升级物品": [],
		"cost": "50000"
	},
	"近战Lv4": {
		"name": "近战Lv4",
		"显示名": "4级战士",
		"parentgroup": "近战Lv3",
		"group": "近战Lv4",
		"升级命令": [],
		"升级物品": [],
		"cost": "125000"
	},
	"近战Lv5": {
		"name": "近战Lv5",
		"显示名": "5级战士",
		"parentgroup": "近战Lv4",
		"group": "近战Lv5",
		"升级命令": [],
		"升级物品": [],
		"cost": "312500"
	},
	"近战Lv6": {
		"name": "近战Lv6",
		"显示名": "6级战士",
		"parentgroup": "近战Lv5",
		"group": "近战Lv6",
		"升级命令": [],
		"升级物品": [],
		"cost": "781250"
	},
	"射手": {
		"name": "射手",
		"显示名": "射手",
		"parentgroup": "Lv2",
		"group": "射手Lv3",
		"升级命令": [],
		"升级物品": [],
		"cost": "50000"
	},
	"射手Lv4": {
		"name": "射手Lv4",
		"显示名": "4级射手",
		"parentgroup": "射手Lv3",
		"group": "射手Lv4",
		"升级命令": [],
		"升级物品": [],
		"cost": "125000"
	},
	"射手Lv5": {
		"name": "射手Lv5",
		"显示名": "5级射手",
		"parentgroup": "射手Lv4",
		"group": "射手Lv5",
		"升级命令": [],
		"升级物品": [],
		"cost": "312500"
	},
	"射手Lv6": {
		"name": "射手Lv6",
		"显示名": "6级射手",
		"parentgroup": "射手Lv5",
		"group": "射手Lv6",
		"升级命令": [],
		"升级物品": [],
		"cost": "781250"
	},
	"法师": {
		"name": "法师",
		"显示名": "法师",
		"parentgroup": "Lv2",
		"group": "法师Lv3",
		"升级命令": [],
		"升级物品": [],
		"cost": "50000"
	},
	"法师Lv4": {
		"name": "法师Lv4",
		"显示名": "4级法师",
		"parentgroup": "法师Lv3",
		"group": "法师Lv4",
		"升级命令": [],
		"升级物品": [],
		"cost": "125000"
	},
	"法师Lv5": {
		"name": "法师Lv5",
		"显示名": "5级法师",
		"parentgroup": "法师Lv4",
		"group": "法师Lv5",
		"升级命令": [],
		"升级物品": [],
		"cost": "312500"
	},
	"法师Lv6": {
		"name": "法师Lv6",
		"显示名": "6级法师",
		"parentgroup": "法师Lv5",
		"group": "法师Lv6",
		"升级命令": [],
		"升级物品": [],
		"cost": "781250"
	},
	"散人": {
		"name": "散人",
		"显示名": "散人",
		"parentgroup": "Lv2",
		"group": "散人Lv3",
		"升级命令": [],
		"升级物品": [],
		"cost": "250000"
	},
	"散人Lv4": {
		"name": "散人Lv4",
		"显示名": "4级散人",
		"parentgroup": "散人Lv3",
		"group": "散人Lv4",
		"升级命令": [],
		"升级物品": [],
		"cost": "625000"
	},
	"散人Lv5": {
		"name": "散人Lv5",
		"显示名": "5级散人",
		"parentgroup": "散人Lv4",
		"group": "散人Lv5",
		"升级命令": [],
		"升级物品": [],
		"cost": "1562500"
	},
	"散人Lv6": {
		"name": "散人Lv6",
		"显示名": "6级散人",
		"parentgroup": "散人Lv5",
		"group": "散人Lv6",
		"升级命令": [],
		"升级物品": [],
		"cost": "3906250"
	},
	"vip": {
		"name": "vip",
		"显示名": "0级vip",
		"parentgroup": "neo",
		"group": "vip",
		"升级命令": [],
		"升级物品": [],
		"cost": "4000"
	},
	"vip1": {
		"name": "vip1",
		"显示名": "1级",
		"parentgroup": "vip",
		"group": "vip1",
		"升级命令": [],
		"升级物品": [],
		"cost": "4000"
	},
	"vip2": {
		"name": "vip2",
		"显示名": "2级",
		"parentgroup": "vip1",
		"group": "vip2",
		"升级命令": [],
		"升级物品": [],
		"cost": "10000"
	},
	"vip3": {
		"name": "vip3",
		"显示名": "3级",
		"parentgroup": "vip2",
		"group": "vip3",
		"升级命令": [],
		"升级物品": [],
		"cost": "25000"
	},
	"vip4": {
		"name": "vip4",
		"显示名": "4级",
		"parentgroup": "vip3",
		"group": "vip4",
		"升级命令": [],
		"升级物品": [],
		"cost": "62500"
	},
	"vip5": {
		"name": "vip5",
		"显示名": "5级",
		"parentgroup": "vip4",
		"group": "vip5",
		"升级命令": [],
		"升级物品": [],
		"cost": "156250"
	},
	"vip6": {
		"name": "vip6",
		"显示名": "6级",
		"parentgroup": "vip5",
		"group": "vip6",
		"升级命令": [],
		"升级物品": [],
		"cost": "390625"
	}
}

//升级全服广播,如果开了，玩家升级的时候就会广播
var 升级全服广播 = true;

//不可升级，有这个权限的人不能升级或转职，给你的管理员用
var 不可升级 = "不可升级";


function rank_for_each_item(enumerable, func)
{
	if (enumerable == undefined || func == undefined) {
		return;
	}

	for (var item in enumerable) {
		if (item == undefined || enumerable.hasOwnProperty(item) == false) {
			continue;
		}
		
		func(enumerable[item]);
	}
}


function rank_find_parent(group)
{
	var parentList = undefined;

	if (rankingList == undefined || group == undefined) {
		return;
	}

	if ((parentList = new Array()) == undefined) {
		return;
	}

	rank_for_each_item(rankingList, function(item) {
		if (item.parentgroup == group) {
			parentList.push(item);
		}
	});

	return parentList;
}


function rank_find(group)
{
	var rank;

	if (group == undefined || rankingList == undefined) {
		return;
	}

	rank_for_each_item(rankingList, function(item) {
		if (item.group == group) {
			rank = item;
		}
	});

	return rank;
}


function rank_find_by_name(rankName)
{
	var rank;

	if (rankName == undefined || rankingList == undefined) {
		return;
	}

	rank_for_each_item(rankingList, function(item) {
		if (item.显示名.toLowerCase() == rankName.toLowerCase()) {
			rank = item;
		}});
	return rank;
}


function rank_starting_rank()
{
	var startingRank;

	if (rankingList === undefined) {
		return;
	}

	rank_for_each_item(rankingList, function(item) {
		if (item.parentgroup === undefined) {
			startingRank = item;
		}
	});

	return startingRank;
}


function rank_error_message(msgLevel) 
{
	if (msgLevel == undefined) {
		return "未知错误，你脸真黑，汉化者从来没遇到过这个错。";
	}

	switch (msgLevel) {
		case 0:
				return "操作成功了，什么错都没有。真是哔了狗了。";
		case -1:
				return "内部错误，操作失败。";
		case -2:
				return "内部错误，收钱（经验）的时候出错了。";
		case -3:
				return "没有找到玩家对应的帐户。";
		case -4:
				return "收钱（经验）失败，估计是没钱（经验）";
		default:
				return "还是未知错误";
	}
}


function rank_move(player, rank) 
{
	var rankCost;
	var seconomyAccount;

	if (player == undefined && rank == undefined) {
		return -1;
	}

	if ((rankCost = seconomy_parse_money(rank.cost)) == undefined) {
		return -2;
	}

	if (rankCost.Value == 0) {
		change_group(player, rank.group);
		rank_for_each_item(rank.升级命令, function(command) {
			execute_command(player, command);
		});
		rank_for_each_item(rank.升级物品, function(command) {
			execute_command(player, "/cni"+command);
		});

		return 0;
	}
	
	if ((seconomyAccount = seconomy_get_account(player)) == undefined) {
		return -3;
	}

	seconomy_pay_async(seconomyAccount, seconomy_world_account(), rankCost, 
					"升级到 " + rank.显示名, function(payResult) {
		if (payResult.TransferSucceeded == false) {
			msg(player, "你的经验不够，没办法升级成 " + rank.显示名 + "。需要" + rankCost + "。");
			return -4;
		}
			
		change_group(player, rank.group);
		rank_for_each_item(rank.升级命令, function(command) {
			execute_command(player, command);
		});
		rank_for_each_item(rank.升级物品, function(command) {
			execute_command(player, "/cni "+command);
		});

		if (升级全服广播) { 
			broadcast_colour("#00AAFF", player.name + " 升级为 " + rank.显示名.replace(/s$/i, '') + "!");
			execute_command(tshock_server(), "/firework \"" + player.Name + "\"" );
		}

		return 0;
	});
}


function rank_move_wrapper(player, rank)
{
	if (player == undefined || rank == undefined) {
		return -1;
	}
	
	if ((moveResult = rank_move(player, rank)) < 0) {
		msg(player, "出了什么鬼奇怪的错: " + rank_error_message(moveResult));
		return -1;
	}

	return 0;
}


function rank_move_next(player, aliasRef)
{
	var rank;
	var nextrankingList;
	var moveResult;
	var nextRank;
	var rankCost;
	var rankString;

	if (player == undefined || rankingList == undefined) {
		return;
	}

	if ((nextRank = rank_starting_rank()) === undefined) {
		msg(player, "等级系统配错了，没法升级。");
		return;
	}

	if ((rank = rank_find(player.Group.Name)) === undefined) {
		rank_move_wrapper(player, rank_starting_rank());
		return;
	}

	if ((nextrankingList = rank_find_parent(rank.group)) == undefined) {
		msg(player, "等级系统配错了，没法升级。");
		return;
	}
	if (nextrankingList.length == 0) {
		msg(player, "你已经满级了！");
		return;
	}
	if (nextrankingList.length == 1 && (nextRank = nextrankingList[0]) != undefined) {
		rank_move_wrapper(player, nextRank);
		return;
	}
	if (nextrankingList.length > 1) {
		msg(player, "你现在是 " + rank.显示名 + "。你需要选择转职了:");
		
		rank_for_each_item(nextrankingList, function(item) {
			rankCost = seconomy_parse_money(item.cost);
			rankString = " * /转职 " + item.显示名;
			
			if (rankCost.Value == 0) {
				rankString += " (免费)";
			} else {
				rankString += " (需要" + rankCost.ToString() + ")";
			}

			msg(player, rankString);
		});

		acmd_cooldown_reset(player, aliasRef);
	}
}


function rank_player_help(player) 
{
	var rank;
	var nextRank;
	var playerText;
	var rankCost;
	var rankString;

	if (player == undefined || rankingList == undefined) {
		return;
	}
	
	if ((rank = rank_find(player.Group.Name)) == undefined) {
		var startingRank;
		if ((startingRank = rank_starting_rank()) === undefined) {
			msg(player, "没有开始的等级，你没办法升级。");
			return;
		}

		msg(player, "你还没有等级，下一级是 " + startingRank.显示名);
		return;
	}
	

	playerText = "你现在是 " + rank.显示名 + "。";
	if ((nextRank = rank_find_parent(rank.group)) === undefined) {
		msg(player, "发生了什么未知的内部错误。截图给服主吧，这种事情挺罕见的。");
		return;
	}
	
	
	if (nextRank.length == 0) {
		playerText += " 你已经满级了！";
		msg(player, playerText);
		return;
	} else if (nextRank.length == 1 && (rank = nextRank[0]) != undefined) {
		playerText += " 下一级是 " + rank.显示名;

		if ((rankCost = seconomy_parse_money(rank.cost)) == undefined) {
			playerText += ".";
		} else {
			if (rankCost.Value > 0) {
				playerText += "，需要" + rankCost.ToString() + "升级。输入\"/升级 \"来升级。";
			} else {
				playerText += ".";
			}
		}
	} else {
		playerText += " 输入/转职 来选择转职吧。";
	}
	msg(player, playerText);

}


acmd_alias_create( "经验", "0c", 0,  "",  function (player, parameters) {
	var command;

	if (tshock_has_permission(player, 不可升级)) {
		msg_colour("#FFDD00", player, "这个号有权限，不需要查询经验。");
		return;
	}
	execute_command(player, "/bank bal" );
	return;
});


acmd_alias_create( "升级", "0c", 0,  "",  function (player, parameters) {
	var command;

	if (rankingList == undefined
		|| player.Group == undefined) {
		return;
	}
	
	if (tshock_has_permission(player, 不可升级)) {
		msg_colour("#FFDD00", player, "这个号有权限，不能升级。");
		return;
	}

	//rank_player_help(player);
	rank_move_next(player, this);
	return;
});


acmd_alias_create("转职", "0c", 0, "", function (player, parameters) {
	var command;
	var chosenClass;
	
	if (rankingList == undefined
		|| player.Group == undefined) {
		return;
	}
	
	if (tshock_has_permission(player, 不可升级)) {
		msg_colour("#FFDD00", player, "这个号有权限，不能转职。");
		return;
	}

	if (parameters.Count == 0
		|| (command = parameters[0]) == "help") {
		rank_player_help(player);
		acmd_cooldown_reset(player, this);
		return;
	}

	if (!(chosenClass = rank_find_by_name(command.toString().toLowerCase()))) {
		msg_colour("#FFDD00", player, "找不到职业 " + command + "。");
		return;
	}

	if (chosenClass.parentgroup.toLowerCase() != rank_find(player.Group.Name).name.toLowerCase()) {
		rank_player_help(player);
		return;
	}

	rank_move_wrapper(player, chosenClass);
});


acmd_alias_create("安装rpg", "0", 0, "安装rpg", function(player, args) {
    execute_command(tshock_server(), "/bank bal");
    execute_command(tshock_server(), "/group addperm default seconomy.world.mobgains");
    execute_command(tshock_server(), "/group add neo");
    execute_command(tshock_server(), "/group add Lv1");
    execute_command(tshock_server(), "/group add Lv2");
    execute_command(tshock_server(), "/group add 近战Lv3");
    execute_command(tshock_server(), "/group add 近战Lv4");
    execute_command(tshock_server(), "/group add 近战Lv5");
    execute_command(tshock_server(), "/group add 近战Lv6");
    execute_command(tshock_server(), "/group add 射手Lv3");
    execute_command(tshock_server(), "/group add 射手Lv4");
    execute_command(tshock_server(), "/group add 射手Lv5");
    execute_command(tshock_server(), "/group add 射手Lv6");
    execute_command(tshock_server(), "/group add 法师Lv3");
    execute_command(tshock_server(), "/group add 法师Lv4");
    execute_command(tshock_server(), "/group add 法师Lv5");
    execute_command(tshock_server(), "/group add 法师Lv6");
    execute_command(tshock_server(), "/group add 散人Lv3");
    execute_command(tshock_server(), "/group add 散人Lv4");
    execute_command(tshock_server(), "/group add 散人Lv5");
    execute_command(tshock_server(), "/group add 散人Lv6");
    execute_command(tshock_server(), "/group add vip1");
    execute_command(tshock_server(), "/group add vip2");
    execute_command(tshock_server(), "/group add vip3");
    execute_command(tshock_server(), "/group add vip4");
    execute_command(tshock_server(), "/group add vip5");
    execute_command(tshock_server(), "/group add vip6");
    execute_command(tshock_server(), "/group prefix default 0级");
    execute_command(tshock_server(), "/group prefix Lv1 1级");
    execute_command(tshock_server(), "/group prefix Lv2 2级");
    execute_command(tshock_server(), "/group prefix 近战Lv3 3级战士");
    execute_command(tshock_server(), "/group prefix 近战Lv4 4级战士");
    execute_command(tshock_server(), "/group prefix 近战Lv5 5级战士");
    execute_command(tshock_server(), "/group prefix 近战Lv6 6级战士");
    execute_command(tshock_server(), "/group prefix 射手Lv3 3级射手");
    execute_command(tshock_server(), "/group prefix 射手Lv4 4级射手");
    execute_command(tshock_server(), "/group prefix 射手Lv5 5级射手");
    execute_command(tshock_server(), "/group prefix 射手Lv6 6级射手");
    execute_command(tshock_server(), "/group prefix 法师Lv3 3级法师");
    execute_command(tshock_server(), "/group prefix 法师Lv4 4级法师");
    execute_command(tshock_server(), "/group prefix 法师Lv5 5级法师");
    execute_command(tshock_server(), "/group prefix 法师Lv6 6级法师");
    execute_command(tshock_server(), "/group prefix 散人Lv3 3级散人");
    execute_command(tshock_server(), "/group prefix 散人Lv4 4级散人");
    execute_command(tshock_server(), "/group prefix 散人Lv5 5级散人");
    execute_command(tshock_server(), "/group prefix 散人Lv6 6级散人");
    execute_command(tshock_server(), "/group prefix vip1 1级vip");
    execute_command(tshock_server(), "/group prefix vip2 2级vip");
    execute_command(tshock_server(), "/group prefix vip3 3级vip");
    execute_command(tshock_server(), "/group prefix vip4 4级vip");
    execute_command(tshock_server(), "/group prefix vip5 5级vip");
    execute_command(tshock_server(), "/group prefix vip6 6级vip");
    execute_command(tshock_server(), "/group parent Lv1 default");
    execute_command(tshock_server(), "/group parent Lv2 Lv1");
    execute_command(tshock_server(), "/group parent 近战Lv3 Lv2");
    execute_command(tshock_server(), "/group parent 近战Lv4 近战Lv3");
    execute_command(tshock_server(), "/group parent 近战Lv5 近战Lv4");
    execute_command(tshock_server(), "/group parent 近战Lv6 近战Lv5");
    execute_command(tshock_server(), "/group parent 射手Lv3 Lv2");
    execute_command(tshock_server(), "/group parent 射手Lv4 射手Lv3");
    execute_command(tshock_server(), "/group parent 射手Lv5 射手Lv4");
    execute_command(tshock_server(), "/group parent 射手Lv6 射手Lv5");
    execute_command(tshock_server(), "/group parent 法师Lv3 Lv2");
    execute_command(tshock_server(), "/group parent 法师Lv4 法师Lv3");
    execute_command(tshock_server(), "/group parent 法师Lv5 法师Lv4");
    execute_command(tshock_server(), "/group parent 法师Lv6 法师Lv5");
    execute_command(tshock_server(), "/group parent 散人Lv3 Lv2");
    execute_command(tshock_server(), "/group parent 散人Lv4 散人Lv3");
    execute_command(tshock_server(), "/group parent 散人Lv5 散人Lv4");
    execute_command(tshock_server(), "/group parent 散人Lv6 散人Lv5");
    execute_command(tshock_server(), "/group parent vip1 vip");
    execute_command(tshock_server(), "/group parent vip2 vip1");
    execute_command(tshock_server(), "/group parent vip3 vip2");
    execute_command(tshock_server(), "/group parent vip4 vip3");
    execute_command(tshock_server(), "/group parent vip5 vip4");
    execute_command(tshock_server(), "/group parent vip6 vip5");
	/*default*/
    execute_command(tshock_server(), "/itemban add 1");
    execute_command(tshock_server(), "/itemban add 24");
    execute_command(tshock_server(), "/itemban add 39");
    execute_command(tshock_server(), "/itemban add 40");
    execute_command(tshock_server(), "/itemban add 42");
    execute_command(tshock_server(), "/itemban add 71");
    execute_command(tshock_server(), "/itemban add 72");
    execute_command(tshock_server(), "/itemban add 73");
    execute_command(tshock_server(), "/itemban add 74");
    execute_command(tshock_server(), "/itemban add 154");
    execute_command(tshock_server(), "/itemban add 161");
    execute_command(tshock_server(), "/itemban add 168");
    execute_command(tshock_server(), "/itemban add 196");
    execute_command(tshock_server(), "/itemban add 279");
    execute_command(tshock_server(), "/itemban add 280");
    execute_command(tshock_server(), "/itemban add 653");
    execute_command(tshock_server(), "/itemban add 654");
    execute_command(tshock_server(), "/itemban add 655");
    execute_command(tshock_server(), "/itemban add 656");
    execute_command(tshock_server(), "/itemban add 657");
    execute_command(tshock_server(), "/itemban add 658");
    execute_command(tshock_server(), "/itemban add 659");
    execute_command(tshock_server(), "/itemban add 660");
    execute_command(tshock_server(), "/itemban add 661");
    execute_command(tshock_server(), "/itemban add 881");
    execute_command(tshock_server(), "/itemban add 882");
    execute_command(tshock_server(), "/itemban add 921");
    execute_command(tshock_server(), "/itemban add 922");
    execute_command(tshock_server(), "/itemban add 929");
    execute_command(tshock_server(), "/itemban add 949");
    execute_command(tshock_server(), "/itemban add 1304");
    execute_command(tshock_server(), "/itemban add 1319");
    execute_command(tshock_server(), "/itemban add 1320");
    execute_command(tshock_server(), "/itemban add 1786");
    execute_command(tshock_server(), "/itemban add 1809");
    execute_command(tshock_server(), "/itemban add 1909");
    execute_command(tshock_server(), "/itemban add 1917");
    execute_command(tshock_server(), "/itemban add 2515");
    execute_command(tshock_server(), "/itemban add 2516");
    execute_command(tshock_server(), "/itemban add 2517");
    execute_command(tshock_server(), "/itemban add 2586");
    execute_command(tshock_server(), "/itemban add 2745");
    execute_command(tshock_server(), "/itemban add 2746");
    execute_command(tshock_server(), "/itemban add 2747");
    execute_command(tshock_server(), "/itemban add 3069");
    execute_command(tshock_server(), "/itemban add 3116");
    execute_command(tshock_server(), "/itemban add 3278");
    execute_command(tshock_server(), "/itemban add 3485");
    execute_command(tshock_server(), "/itemban add 3491");
    execute_command(tshock_server(), "/itemban add 3497");
    execute_command(tshock_server(), "/itemban add 3503");
    execute_command(tshock_server(), "/itemban add 3509");
    execute_command(tshock_server(), "/itemban add 3515");
    execute_command(tshock_server(), "/itemban add 3521");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1 default");
    execute_command(tshock_server(), "/itemban allow 24 default");
    execute_command(tshock_server(), "/itemban allow 39 default");
    execute_command(tshock_server(), "/itemban allow 40 default");
    execute_command(tshock_server(), "/itemban allow 42 default");
    execute_command(tshock_server(), "/itemban allow 71 default");
    execute_command(tshock_server(), "/itemban allow 72 default");
    execute_command(tshock_server(), "/itemban allow 73 default");
    execute_command(tshock_server(), "/itemban allow 74 default");
    execute_command(tshock_server(), "/itemban allow 154 default");
    execute_command(tshock_server(), "/itemban allow 161 default");
    execute_command(tshock_server(), "/itemban allow 168 default");
    execute_command(tshock_server(), "/itemban allow 196 default");
    execute_command(tshock_server(), "/itemban allow 279 default");
    execute_command(tshock_server(), "/itemban allow 280 default");
    execute_command(tshock_server(), "/itemban allow 653 default");
    execute_command(tshock_server(), "/itemban allow 654 default");
    execute_command(tshock_server(), "/itemban allow 655 default");
    execute_command(tshock_server(), "/itemban allow 656 default");
    execute_command(tshock_server(), "/itemban allow 657 default");
    execute_command(tshock_server(), "/itemban allow 658 default");
    execute_command(tshock_server(), "/itemban allow 659 default");
    execute_command(tshock_server(), "/itemban allow 660 default");
    execute_command(tshock_server(), "/itemban allow 661 default");
    execute_command(tshock_server(), "/itemban allow 881 default");
    execute_command(tshock_server(), "/itemban allow 882 default");
    execute_command(tshock_server(), "/itemban allow 921 default");
    execute_command(tshock_server(), "/itemban allow 922 default");
    execute_command(tshock_server(), "/itemban allow 929 default");
    execute_command(tshock_server(), "/itemban allow 949 default");
    execute_command(tshock_server(), "/itemban allow 1304 default");
    execute_command(tshock_server(), "/itemban allow 1319 default");
    execute_command(tshock_server(), "/itemban allow 1320 default");
    execute_command(tshock_server(), "/itemban allow 1786 default");
    execute_command(tshock_server(), "/itemban allow 1809 default");
    execute_command(tshock_server(), "/itemban allow 1909 default");
    execute_command(tshock_server(), "/itemban allow 1917 default");
    execute_command(tshock_server(), "/itemban allow 2515 default");
    execute_command(tshock_server(), "/itemban allow 2516 default");
    execute_command(tshock_server(), "/itemban allow 2517 default");
    execute_command(tshock_server(), "/itemban allow 2586 default");
    execute_command(tshock_server(), "/itemban allow 2745 default");
    execute_command(tshock_server(), "/itemban allow 2746 default");
    execute_command(tshock_server(), "/itemban allow 2747 default");
    execute_command(tshock_server(), "/itemban allow 3069 default");
    execute_command(tshock_server(), "/itemban allow 3116 default");
    execute_command(tshock_server(), "/itemban allow 3278 default");
    execute_command(tshock_server(), "/itemban allow 3485 default");
    execute_command(tshock_server(), "/itemban allow 3491 default");
    execute_command(tshock_server(), "/itemban allow 3497 default");
    execute_command(tshock_server(), "/itemban allow 3503 default");
    execute_command(tshock_server(), "/itemban allow 3509 default");
    execute_command(tshock_server(), "/itemban allow 3515 default");
    execute_command(tshock_server(), "/itemban allow 3521 default");
	/*Lv1*/
    execute_command(tshock_server(), "/itemban add 4");
    execute_command(tshock_server(), "/itemban add 6");
    execute_command(tshock_server(), "/itemban add 7");
    execute_command(tshock_server(), "/itemban add 10");
    execute_command(tshock_server(), "/itemban add 41");
    execute_command(tshock_server(), "/itemban add 44");
    execute_command(tshock_server(), "/itemban add 45");
    execute_command(tshock_server(), "/itemban add 46");
    execute_command(tshock_server(), "/itemban add 47");
    execute_command(tshock_server(), "/itemban add 51");
    execute_command(tshock_server(), "/itemban add 55");
    execute_command(tshock_server(), "/itemban add 64");
    execute_command(tshock_server(), "/itemban add 65");
    execute_command(tshock_server(), "/itemban add 95");
    execute_command(tshock_server(), "/itemban add 96");
    execute_command(tshock_server(), "/itemban add 97");
    execute_command(tshock_server(), "/itemban add 99");
    execute_command(tshock_server(), "/itemban add 103");
    execute_command(tshock_server(), "/itemban add 104");
    execute_command(tshock_server(), "/itemban add 104");
    execute_command(tshock_server(), "/itemban add 127");
    execute_command(tshock_server(), "/itemban add 155");
    execute_command(tshock_server(), "/itemban add 157");
    execute_command(tshock_server(), "/itemban add 160");
    execute_command(tshock_server(), "/itemban add 162");
    execute_command(tshock_server(), "/itemban add 163");
    execute_command(tshock_server(), "/itemban add 165");
    execute_command(tshock_server(), "/itemban add 190");
    execute_command(tshock_server(), "/itemban add 191");
    execute_command(tshock_server(), "/itemban add 197");
    execute_command(tshock_server(), "/itemban add 198");
    execute_command(tshock_server(), "/itemban add 199");
    execute_command(tshock_server(), "/itemban add 200");
    execute_command(tshock_server(), "/itemban add 201");
    execute_command(tshock_server(), "/itemban add 202");
    execute_command(tshock_server(), "/itemban add 203");
    execute_command(tshock_server(), "/itemban add 204");
    execute_command(tshock_server(), "/itemban add 213");
    execute_command(tshock_server(), "/itemban add 234");
    execute_command(tshock_server(), "/itemban add 277");
    execute_command(tshock_server(), "/itemban add 278");
    execute_command(tshock_server(), "/itemban add 281");
    execute_command(tshock_server(), "/itemban add 283");
    execute_command(tshock_server(), "/itemban add 284");
    execute_command(tshock_server(), "/itemban add 287");
    execute_command(tshock_server(), "/itemban add 516");
    execute_command(tshock_server(), "/itemban add 534");
    execute_command(tshock_server(), "/itemban add 670");
    execute_command(tshock_server(), "/itemban add 724");
    execute_command(tshock_server(), "/itemban add 739");
    execute_command(tshock_server(), "/itemban add 740");
    execute_command(tshock_server(), "/itemban add 741");
    execute_command(tshock_server(), "/itemban add 742");
    execute_command(tshock_server(), "/itemban add 795");
    execute_command(tshock_server(), "/itemban add 796");
    execute_command(tshock_server(), "/itemban add 797");
    execute_command(tshock_server(), "/itemban add 798");
    execute_command(tshock_server(), "/itemban add 799");
    execute_command(tshock_server(), "/itemban add 800");
    execute_command(tshock_server(), "/itemban add 801");
    execute_command(tshock_server(), "/itemban add 802");
    execute_command(tshock_server(), "/itemban add 930");
    execute_command(tshock_server(), "/itemban add 931");
    execute_command(tshock_server(), "/itemban add 964");
    execute_command(tshock_server(), "/itemban add 989");
    execute_command(tshock_server(), "/itemban add 1121");
    execute_command(tshock_server(), "/itemban add 1123");
    execute_command(tshock_server(), "/itemban add 1166");
    execute_command(tshock_server(), "/itemban add 1256");
    execute_command(tshock_server(), "/itemban add 1309");
    execute_command(tshock_server(), "/itemban add 1325");
    execute_command(tshock_server(), "/itemban add 1614");
    execute_command(tshock_server(), "/itemban add 1825");
    execute_command(tshock_server(), "/itemban add 1870");
    execute_command(tshock_server(), "/itemban add 1913");
    execute_command(tshock_server(), "/itemban add 1918");
    execute_command(tshock_server(), "/itemban add 2269");
    execute_command(tshock_server(), "/itemban add 2273");
    execute_command(tshock_server(), "/itemban add 2320");
    execute_command(tshock_server(), "/itemban add 2330");
    execute_command(tshock_server(), "/itemban add 2364");
    execute_command(tshock_server(), "/itemban add 3003");
    execute_command(tshock_server(), "/itemban add 3019");
    execute_command(tshock_server(), "/itemban add 3094");
    execute_command(tshock_server(), "/itemban add 3197");
    execute_command(tshock_server(), "/itemban add 3245");
    execute_command(tshock_server(), "/itemban add 3262");
    execute_command(tshock_server(), "/itemban add 3279");
    execute_command(tshock_server(), "/itemban add 3280");
    execute_command(tshock_server(), "/itemban add 3281");
    execute_command(tshock_server(), "/itemban add 3285");
    execute_command(tshock_server(), "/itemban add 3317");
    execute_command(tshock_server(), "/itemban add 3349");
    execute_command(tshock_server(), "/itemban add 3351");
    execute_command(tshock_server(), "/itemban add 3352");
    execute_command(tshock_server(), "/itemban add 3378");
    execute_command(tshock_server(), "/itemban add 3379");
    execute_command(tshock_server(), "/itemban add 3480");
    execute_command(tshock_server(), "/itemban add 3481");
    execute_command(tshock_server(), "/itemban add 3482");
    execute_command(tshock_server(), "/itemban add 3483");
    execute_command(tshock_server(), "/itemban add 3484");
    execute_command(tshock_server(), "/itemban add 3486");
    execute_command(tshock_server(), "/itemban add 3487");
    execute_command(tshock_server(), "/itemban add 3488");
    execute_command(tshock_server(), "/itemban add 3489");
    execute_command(tshock_server(), "/itemban add 3490");
    execute_command(tshock_server(), "/itemban add 3492");
    execute_command(tshock_server(), "/itemban add 3493");
    execute_command(tshock_server(), "/itemban add 3494");
    execute_command(tshock_server(), "/itemban add 3495");
    execute_command(tshock_server(), "/itemban add 3496");
    execute_command(tshock_server(), "/itemban add 3498");
    execute_command(tshock_server(), "/itemban add 3499");
    execute_command(tshock_server(), "/itemban add 3500");
    execute_command(tshock_server(), "/itemban add 3501");
    execute_command(tshock_server(), "/itemban add 3502");
    execute_command(tshock_server(), "/itemban add 3504");
    execute_command(tshock_server(), "/itemban add 3505");
    execute_command(tshock_server(), "/itemban add 3506");
    execute_command(tshock_server(), "/itemban add 3507");
    execute_command(tshock_server(), "/itemban add 3508");
    execute_command(tshock_server(), "/itemban add 3510");
    execute_command(tshock_server(), "/itemban add 3511");
    execute_command(tshock_server(), "/itemban add 3512");
    execute_command(tshock_server(), "/itemban add 3513");
    execute_command(tshock_server(), "/itemban add 3514");
    execute_command(tshock_server(), "/itemban add 3516");
    execute_command(tshock_server(), "/itemban add 3517");
    execute_command(tshock_server(), "/itemban add 3518");
    execute_command(tshock_server(), "/itemban add 3519");
    execute_command(tshock_server(), "/itemban add 3520");
    execute_command(tshock_server(), "/itemban add 3548");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 4 Lv1");
    execute_command(tshock_server(), "/itemban allow 6 Lv1");
    execute_command(tshock_server(), "/itemban allow 7 Lv1");
    execute_command(tshock_server(), "/itemban allow 10 Lv1");
    execute_command(tshock_server(), "/itemban allow 41 Lv1");
    execute_command(tshock_server(), "/itemban allow 44 Lv1");
    execute_command(tshock_server(), "/itemban allow 45 Lv1");
    execute_command(tshock_server(), "/itemban allow 46 Lv1");
    execute_command(tshock_server(), "/itemban allow 47 Lv1");
    execute_command(tshock_server(), "/itemban allow 51 Lv1");
    execute_command(tshock_server(), "/itemban allow 55 Lv1");
    execute_command(tshock_server(), "/itemban allow 64 Lv1");
    execute_command(tshock_server(), "/itemban allow 65 Lv1");
    execute_command(tshock_server(), "/itemban allow 95 Lv1");
    execute_command(tshock_server(), "/itemban allow 96 Lv1");
    execute_command(tshock_server(), "/itemban allow 97 Lv1");
    execute_command(tshock_server(), "/itemban allow 99 Lv1");
    execute_command(tshock_server(), "/itemban allow 103 Lv1");
    execute_command(tshock_server(), "/itemban allow 104 Lv1");
    execute_command(tshock_server(), "/itemban allow 104 Lv1");
    execute_command(tshock_server(), "/itemban allow 127 Lv1");
    execute_command(tshock_server(), "/itemban allow 155 Lv1");
    execute_command(tshock_server(), "/itemban allow 157 Lv1");
    execute_command(tshock_server(), "/itemban allow 160 Lv1");
    execute_command(tshock_server(), "/itemban allow 162 Lv1");
    execute_command(tshock_server(), "/itemban allow 163 Lv1");
    execute_command(tshock_server(), "/itemban allow 165 Lv1");
    execute_command(tshock_server(), "/itemban allow 190 Lv1");
    execute_command(tshock_server(), "/itemban allow 191 Lv1");
    execute_command(tshock_server(), "/itemban allow 197 Lv1");
    execute_command(tshock_server(), "/itemban allow 198 Lv1");
    execute_command(tshock_server(), "/itemban allow 199 Lv1");
    execute_command(tshock_server(), "/itemban allow 200 Lv1");
    execute_command(tshock_server(), "/itemban allow 201 Lv1");
    execute_command(tshock_server(), "/itemban allow 202 Lv1");
    execute_command(tshock_server(), "/itemban allow 203 Lv1");
    execute_command(tshock_server(), "/itemban allow 204 Lv1");
    execute_command(tshock_server(), "/itemban allow 213 Lv1");
    execute_command(tshock_server(), "/itemban allow 234 Lv1");
    execute_command(tshock_server(), "/itemban allow 277 Lv1");
    execute_command(tshock_server(), "/itemban allow 278 Lv1");
    execute_command(tshock_server(), "/itemban allow 281 Lv1");
    execute_command(tshock_server(), "/itemban allow 283 Lv1");
    execute_command(tshock_server(), "/itemban allow 284 Lv1");
    execute_command(tshock_server(), "/itemban allow 287 Lv1");
    execute_command(tshock_server(), "/itemban allow 516 Lv1");
    execute_command(tshock_server(), "/itemban allow 534 Lv1");
    execute_command(tshock_server(), "/itemban allow 670 Lv1");
    execute_command(tshock_server(), "/itemban allow 724 Lv1");
    execute_command(tshock_server(), "/itemban allow 739 Lv1");
    execute_command(tshock_server(), "/itemban allow 740 Lv1");
    execute_command(tshock_server(), "/itemban allow 741 Lv1");
    execute_command(tshock_server(), "/itemban allow 742 Lv1");
    execute_command(tshock_server(), "/itemban allow 795 Lv1");
    execute_command(tshock_server(), "/itemban allow 796 Lv1");
    execute_command(tshock_server(), "/itemban allow 797 Lv1");
    execute_command(tshock_server(), "/itemban allow 798 Lv1");
    execute_command(tshock_server(), "/itemban allow 799 Lv1");
    execute_command(tshock_server(), "/itemban allow 800 Lv1");
    execute_command(tshock_server(), "/itemban allow 801 Lv1");
    execute_command(tshock_server(), "/itemban allow 802 Lv1");
    execute_command(tshock_server(), "/itemban allow 930 Lv1");
    execute_command(tshock_server(), "/itemban allow 931 Lv1");
    execute_command(tshock_server(), "/itemban allow 964 Lv1");
    execute_command(tshock_server(), "/itemban allow 989 Lv1");
    execute_command(tshock_server(), "/itemban allow 1121 Lv1");
    execute_command(tshock_server(), "/itemban allow 1123 Lv1");
    execute_command(tshock_server(), "/itemban allow 1166 Lv1");
    execute_command(tshock_server(), "/itemban allow 1256 Lv1");
    execute_command(tshock_server(), "/itemban allow 1309 Lv1");
    execute_command(tshock_server(), "/itemban allow 1325 Lv1");
    execute_command(tshock_server(), "/itemban allow 1614 Lv1");
    execute_command(tshock_server(), "/itemban allow 1825 Lv1");
    execute_command(tshock_server(), "/itemban allow 1870 Lv1");
    execute_command(tshock_server(), "/itemban allow 1913 Lv1");
    execute_command(tshock_server(), "/itemban allow 1918 Lv1");
    execute_command(tshock_server(), "/itemban allow 2269 Lv1");
    execute_command(tshock_server(), "/itemban allow 2273 Lv1");
    execute_command(tshock_server(), "/itemban allow 2320 Lv1");
    execute_command(tshock_server(), "/itemban allow 2330 Lv1");
    execute_command(tshock_server(), "/itemban allow 2364 Lv1");
    execute_command(tshock_server(), "/itemban allow 3003 Lv1");
    execute_command(tshock_server(), "/itemban allow 3019 Lv1");
    execute_command(tshock_server(), "/itemban allow 3094 Lv1");
    execute_command(tshock_server(), "/itemban allow 3197 Lv1");
    execute_command(tshock_server(), "/itemban allow 3245 Lv1");
    execute_command(tshock_server(), "/itemban allow 3262 Lv1");
    execute_command(tshock_server(), "/itemban allow 3279 Lv1");
    execute_command(tshock_server(), "/itemban allow 3280 Lv1");
    execute_command(tshock_server(), "/itemban allow 3281 Lv1");
    execute_command(tshock_server(), "/itemban allow 3285 Lv1");
    execute_command(tshock_server(), "/itemban allow 3317 Lv1");
    execute_command(tshock_server(), "/itemban allow 3349 Lv1");
    execute_command(tshock_server(), "/itemban allow 3351 Lv1");
    execute_command(tshock_server(), "/itemban allow 3352 Lv1");
    execute_command(tshock_server(), "/itemban allow 3378 Lv1");
    execute_command(tshock_server(), "/itemban allow 3379 Lv1");
    execute_command(tshock_server(), "/itemban allow 3480 Lv1");
    execute_command(tshock_server(), "/itemban allow 3481 Lv1");
    execute_command(tshock_server(), "/itemban allow 3482 Lv1");
    execute_command(tshock_server(), "/itemban allow 3483 Lv1");
    execute_command(tshock_server(), "/itemban allow 3484 Lv1");
    execute_command(tshock_server(), "/itemban allow 3486 Lv1");
    execute_command(tshock_server(), "/itemban allow 3487 Lv1");
    execute_command(tshock_server(), "/itemban allow 3488 Lv1");
    execute_command(tshock_server(), "/itemban allow 3489 Lv1");
    execute_command(tshock_server(), "/itemban allow 3490 Lv1");
    execute_command(tshock_server(), "/itemban allow 3492 Lv1");
    execute_command(tshock_server(), "/itemban allow 3493 Lv1");
    execute_command(tshock_server(), "/itemban allow 3494 Lv1");
    execute_command(tshock_server(), "/itemban allow 3495 Lv1");
    execute_command(tshock_server(), "/itemban allow 3496 Lv1");
    execute_command(tshock_server(), "/itemban allow 3498 Lv1");
    execute_command(tshock_server(), "/itemban allow 3499 Lv1");
    execute_command(tshock_server(), "/itemban allow 3500 Lv1");
    execute_command(tshock_server(), "/itemban allow 3501 Lv1");
    execute_command(tshock_server(), "/itemban allow 3502 Lv1");
    execute_command(tshock_server(), "/itemban allow 3504 Lv1");
    execute_command(tshock_server(), "/itemban allow 3505 Lv1");
    execute_command(tshock_server(), "/itemban allow 3506 Lv1");
    execute_command(tshock_server(), "/itemban allow 3507 Lv1");
    execute_command(tshock_server(), "/itemban allow 3508 Lv1");
    execute_command(tshock_server(), "/itemban allow 3510 Lv1");
    execute_command(tshock_server(), "/itemban allow 3511 Lv1");
    execute_command(tshock_server(), "/itemban allow 3512 Lv1");
    execute_command(tshock_server(), "/itemban allow 3513 Lv1");
    execute_command(tshock_server(), "/itemban allow 3514 Lv1");
    execute_command(tshock_server(), "/itemban allow 3516 Lv1");
    execute_command(tshock_server(), "/itemban allow 3517 Lv1");
    execute_command(tshock_server(), "/itemban allow 3518 Lv1");
    execute_command(tshock_server(), "/itemban allow 3519 Lv1");
    execute_command(tshock_server(), "/itemban allow 3520 Lv1");
    execute_command(tshock_server(), "/itemban allow 3548 Lv1");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 4 vip1");
    execute_command(tshock_server(), "/itemban allow 6 vip1");
    execute_command(tshock_server(), "/itemban allow 7 vip1");
    execute_command(tshock_server(), "/itemban allow 10 vip1");
    execute_command(tshock_server(), "/itemban allow 41 vip1");
    execute_command(tshock_server(), "/itemban allow 44 vip1");
    execute_command(tshock_server(), "/itemban allow 45 vip1");
    execute_command(tshock_server(), "/itemban allow 46 vip1");
    execute_command(tshock_server(), "/itemban allow 47 vip1");
    execute_command(tshock_server(), "/itemban allow 51 vip1");
    execute_command(tshock_server(), "/itemban allow 55 vip1");
    execute_command(tshock_server(), "/itemban allow 64 vip1");
    execute_command(tshock_server(), "/itemban allow 65 vip1");
    execute_command(tshock_server(), "/itemban allow 95 vip1");
    execute_command(tshock_server(), "/itemban allow 96 vip1");
    execute_command(tshock_server(), "/itemban allow 97 vip1");
    execute_command(tshock_server(), "/itemban allow 99 vip1");
    execute_command(tshock_server(), "/itemban allow 103 vip1");
    execute_command(tshock_server(), "/itemban allow 104 vip1");
    execute_command(tshock_server(), "/itemban allow 104 vip1");
    execute_command(tshock_server(), "/itemban allow 127 vip1");
    execute_command(tshock_server(), "/itemban allow 155 vip1");
    execute_command(tshock_server(), "/itemban allow 157 vip1");
    execute_command(tshock_server(), "/itemban allow 160 vip1");
    execute_command(tshock_server(), "/itemban allow 162 vip1");
    execute_command(tshock_server(), "/itemban allow 163 vip1");
    execute_command(tshock_server(), "/itemban allow 165 vip1");
    execute_command(tshock_server(), "/itemban allow 190 vip1");
    execute_command(tshock_server(), "/itemban allow 191 vip1");
    execute_command(tshock_server(), "/itemban allow 197 vip1");
    execute_command(tshock_server(), "/itemban allow 198 vip1");
    execute_command(tshock_server(), "/itemban allow 199 vip1");
    execute_command(tshock_server(), "/itemban allow 200 vip1");
    execute_command(tshock_server(), "/itemban allow 201 vip1");
    execute_command(tshock_server(), "/itemban allow 202 vip1");
    execute_command(tshock_server(), "/itemban allow 203 vip1");
    execute_command(tshock_server(), "/itemban allow 204 vip1");
    execute_command(tshock_server(), "/itemban allow 213 vip1");
    execute_command(tshock_server(), "/itemban allow 234 vip1");
    execute_command(tshock_server(), "/itemban allow 277 vip1");
    execute_command(tshock_server(), "/itemban allow 278 vip1");
    execute_command(tshock_server(), "/itemban allow 281 vip1");
    execute_command(tshock_server(), "/itemban allow 283 vip1");
    execute_command(tshock_server(), "/itemban allow 284 vip1");
    execute_command(tshock_server(), "/itemban allow 287 vip1");
    execute_command(tshock_server(), "/itemban allow 516 vip1");
    execute_command(tshock_server(), "/itemban allow 534 vip1");
    execute_command(tshock_server(), "/itemban allow 670 vip1");
    execute_command(tshock_server(), "/itemban allow 724 vip1");
    execute_command(tshock_server(), "/itemban allow 739 vip1");
    execute_command(tshock_server(), "/itemban allow 740 vip1");
    execute_command(tshock_server(), "/itemban allow 741 vip1");
    execute_command(tshock_server(), "/itemban allow 742 vip1");
    execute_command(tshock_server(), "/itemban allow 795 vip1");
    execute_command(tshock_server(), "/itemban allow 796 vip1");
    execute_command(tshock_server(), "/itemban allow 797 vip1");
    execute_command(tshock_server(), "/itemban allow 798 vip1");
    execute_command(tshock_server(), "/itemban allow 799 vip1");
    execute_command(tshock_server(), "/itemban allow 800 vip1");
    execute_command(tshock_server(), "/itemban allow 801 vip1");
    execute_command(tshock_server(), "/itemban allow 802 vip1");
    execute_command(tshock_server(), "/itemban allow 930 vip1");
    execute_command(tshock_server(), "/itemban allow 931 vip1");
    execute_command(tshock_server(), "/itemban allow 964 vip1");
    execute_command(tshock_server(), "/itemban allow 989 vip1");
    execute_command(tshock_server(), "/itemban allow 1121 vip1");
    execute_command(tshock_server(), "/itemban allow 1123 vip1");
    execute_command(tshock_server(), "/itemban allow 1166 vip1");
    execute_command(tshock_server(), "/itemban allow 1256 vip1");
    execute_command(tshock_server(), "/itemban allow 1309 vip1");
    execute_command(tshock_server(), "/itemban allow 1325 vip1");
    execute_command(tshock_server(), "/itemban allow 1614 vip1");
    execute_command(tshock_server(), "/itemban allow 1825 vip1");
    execute_command(tshock_server(), "/itemban allow 1870 vip1");
    execute_command(tshock_server(), "/itemban allow 1913 vip1");
    execute_command(tshock_server(), "/itemban allow 1918 vip1");
    execute_command(tshock_server(), "/itemban allow 2269 vip1");
    execute_command(tshock_server(), "/itemban allow 2273 vip1");
    execute_command(tshock_server(), "/itemban allow 2320 vip1");
    execute_command(tshock_server(), "/itemban allow 2330 vip1");
    execute_command(tshock_server(), "/itemban allow 2364 vip1");
    execute_command(tshock_server(), "/itemban allow 3003 vip1");
    execute_command(tshock_server(), "/itemban allow 3019 vip1");
    execute_command(tshock_server(), "/itemban allow 3094 vip1");
    execute_command(tshock_server(), "/itemban allow 3197 vip1");
    execute_command(tshock_server(), "/itemban allow 3245 vip1");
    execute_command(tshock_server(), "/itemban allow 3262 vip1");
    execute_command(tshock_server(), "/itemban allow 3279 vip1");
    execute_command(tshock_server(), "/itemban allow 3280 vip1");
    execute_command(tshock_server(), "/itemban allow 3281 vip1");
    execute_command(tshock_server(), "/itemban allow 3285 vip1");
    execute_command(tshock_server(), "/itemban allow 3317 vip1");
    execute_command(tshock_server(), "/itemban allow 3349 vip1");
    execute_command(tshock_server(), "/itemban allow 3351 vip1");
    execute_command(tshock_server(), "/itemban allow 3352 vip1");
    execute_command(tshock_server(), "/itemban allow 3378 vip1");
    execute_command(tshock_server(), "/itemban allow 3379 vip1");
    execute_command(tshock_server(), "/itemban allow 3480 vip1");
    execute_command(tshock_server(), "/itemban allow 3481 vip1");
    execute_command(tshock_server(), "/itemban allow 3482 vip1");
    execute_command(tshock_server(), "/itemban allow 3483 vip1");
    execute_command(tshock_server(), "/itemban allow 3484 vip1");
    execute_command(tshock_server(), "/itemban allow 3486 vip1");
    execute_command(tshock_server(), "/itemban allow 3487 vip1");
    execute_command(tshock_server(), "/itemban allow 3488 vip1");
    execute_command(tshock_server(), "/itemban allow 3489 vip1");
    execute_command(tshock_server(), "/itemban allow 3490 vip1");
    execute_command(tshock_server(), "/itemban allow 3492 vip1");
    execute_command(tshock_server(), "/itemban allow 3493 vip1");
    execute_command(tshock_server(), "/itemban allow 3494 vip1");
    execute_command(tshock_server(), "/itemban allow 3495 vip1");
    execute_command(tshock_server(), "/itemban allow 3496 vip1");
    execute_command(tshock_server(), "/itemban allow 3498 vip1");
    execute_command(tshock_server(), "/itemban allow 3499 vip1");
    execute_command(tshock_server(), "/itemban allow 3500 vip1");
    execute_command(tshock_server(), "/itemban allow 3501 vip1");
    execute_command(tshock_server(), "/itemban allow 3502 vip1");
    execute_command(tshock_server(), "/itemban allow 3504 vip1");
    execute_command(tshock_server(), "/itemban allow 3505 vip1");
    execute_command(tshock_server(), "/itemban allow 3506 vip1");
    execute_command(tshock_server(), "/itemban allow 3507 vip1");
    execute_command(tshock_server(), "/itemban allow 3508 vip1");
    execute_command(tshock_server(), "/itemban allow 3510 vip1");
    execute_command(tshock_server(), "/itemban allow 3511 vip1");
    execute_command(tshock_server(), "/itemban allow 3512 vip1");
    execute_command(tshock_server(), "/itemban allow 3513 vip1");
    execute_command(tshock_server(), "/itemban allow 3514 vip1");
    execute_command(tshock_server(), "/itemban allow 3516 vip1");
    execute_command(tshock_server(), "/itemban allow 3517 vip1");
    execute_command(tshock_server(), "/itemban allow 3518 vip1");
    execute_command(tshock_server(), "/itemban allow 3519 vip1");
    execute_command(tshock_server(), "/itemban allow 3520 vip1");
    execute_command(tshock_server(), "/itemban allow 3548 vip1");
    /*Lv2*/
    execute_command(tshock_server(), "/itemban add 98");
    execute_command(tshock_server(), "/itemban add 113");
    execute_command(tshock_server(), "/itemban add 119");
    execute_command(tshock_server(), "/itemban add 120");
    execute_command(tshock_server(), "/itemban add 121");
    execute_command(tshock_server(), "/itemban add 122");
    execute_command(tshock_server(), "/itemban add 217");
    execute_command(tshock_server(), "/itemban add 219");
    execute_command(tshock_server(), "/itemban add 220");
    execute_command(tshock_server(), "/itemban add 265");
    execute_command(tshock_server(), "/itemban add 266");
    execute_command(tshock_server(), "/itemban add 272");
    execute_command(tshock_server(), "/itemban add 273");
    execute_command(tshock_server(), "/itemban add 274");
    execute_command(tshock_server(), "/itemban add 367");
    execute_command(tshock_server(), "/itemban add 434");
    execute_command(tshock_server(), "/itemban add 743");
    execute_command(tshock_server(), "/itemban add 744");
    execute_command(tshock_server(), "/itemban add 986");
    execute_command(tshock_server(), "/itemban add 1130");
    execute_command(tshock_server(), "/itemban add 1313");
    execute_command(tshock_server(), "/itemban add 1827");
    execute_command(tshock_server(), "/itemban add 2270");
    execute_command(tshock_server(), "/itemban add 2332");
    execute_command(tshock_server(), "/itemban add 2341");
    execute_command(tshock_server(), "/itemban add 2342");
    execute_command(tshock_server(), "/itemban add 2365");
    execute_command(tshock_server(), "/itemban add 2366");
    execute_command(tshock_server(), "/itemban add 2551");
    execute_command(tshock_server(), "/itemban add 2590");
    execute_command(tshock_server(), "/itemban add 2608");
    execute_command(tshock_server(), "/itemban add 2888");
    execute_command(tshock_server(), "/itemban add 3051");
    execute_command(tshock_server(), "/itemban add 3097");
    execute_command(tshock_server(), "/itemban add 3282");
    execute_command(tshock_server(), "/itemban add 3315");
    execute_command(tshock_server(), "/itemban add 3368");
    execute_command(tshock_server(), "/itemban add 3377");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 98 Lv2");
    execute_command(tshock_server(), "/itemban allow 113 Lv2");
    execute_command(tshock_server(), "/itemban allow 119 Lv2");
    execute_command(tshock_server(), "/itemban allow 120 Lv2");
    execute_command(tshock_server(), "/itemban allow 121 Lv2");
    execute_command(tshock_server(), "/itemban allow 122 Lv2");
    execute_command(tshock_server(), "/itemban allow 217 Lv2");
    execute_command(tshock_server(), "/itemban allow 219 Lv2");
    execute_command(tshock_server(), "/itemban allow 220 Lv2");
    execute_command(tshock_server(), "/itemban allow 265 Lv2");
    execute_command(tshock_server(), "/itemban allow 266 Lv2");
    execute_command(tshock_server(), "/itemban allow 272 Lv2");
    execute_command(tshock_server(), "/itemban allow 273 Lv2");
    execute_command(tshock_server(), "/itemban allow 274 Lv2");
    execute_command(tshock_server(), "/itemban allow 367 Lv2");
    execute_command(tshock_server(), "/itemban allow 434 Lv2");
    execute_command(tshock_server(), "/itemban allow 743 Lv2");
    execute_command(tshock_server(), "/itemban allow 744 Lv2");
    execute_command(tshock_server(), "/itemban allow 986 Lv2");
    execute_command(tshock_server(), "/itemban allow 1130 Lv2");
    execute_command(tshock_server(), "/itemban allow 1313 Lv2");
    execute_command(tshock_server(), "/itemban allow 1827 Lv2");
    execute_command(tshock_server(), "/itemban allow 2270 Lv2");
    execute_command(tshock_server(), "/itemban allow 2332 Lv2");
    execute_command(tshock_server(), "/itemban allow 2341 Lv2");
    execute_command(tshock_server(), "/itemban allow 2342 Lv2");
    execute_command(tshock_server(), "/itemban allow 2365 Lv2");
    execute_command(tshock_server(), "/itemban allow 2366 Lv2");
    execute_command(tshock_server(), "/itemban allow 2551 Lv2");
    execute_command(tshock_server(), "/itemban allow 2590 Lv2");
    execute_command(tshock_server(), "/itemban allow 2608 Lv2");
    execute_command(tshock_server(), "/itemban allow 2888 Lv2");
    execute_command(tshock_server(), "/itemban allow 3051 Lv2");
    execute_command(tshock_server(), "/itemban allow 3097 Lv2");
    execute_command(tshock_server(), "/itemban allow 3282 Lv2");
    execute_command(tshock_server(), "/itemban allow 3315 Lv2");
    execute_command(tshock_server(), "/itemban allow 3368 Lv2");
    execute_command(tshock_server(), "/itemban allow 3377 Lv2");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 98 vip2");
    execute_command(tshock_server(), "/itemban allow 113 vip2");
    execute_command(tshock_server(), "/itemban allow 119 vip2");
    execute_command(tshock_server(), "/itemban allow 120 vip2");
    execute_command(tshock_server(), "/itemban allow 121 vip2");
    execute_command(tshock_server(), "/itemban allow 122 vip2");
    execute_command(tshock_server(), "/itemban allow 217 vip2");
    execute_command(tshock_server(), "/itemban allow 219 vip2");
    execute_command(tshock_server(), "/itemban allow 220 vip2");
    execute_command(tshock_server(), "/itemban allow 265 vip2");
    execute_command(tshock_server(), "/itemban allow 266 vip2");
    execute_command(tshock_server(), "/itemban allow 272 vip2");
    execute_command(tshock_server(), "/itemban allow 273 vip2");
    execute_command(tshock_server(), "/itemban allow 274 vip2");
    execute_command(tshock_server(), "/itemban allow 367 vip2");
    execute_command(tshock_server(), "/itemban allow 434 vip2");
    execute_command(tshock_server(), "/itemban allow 743 vip2");
    execute_command(tshock_server(), "/itemban allow 744 vip2");
    execute_command(tshock_server(), "/itemban allow 986 vip2");
    execute_command(tshock_server(), "/itemban allow 1130 vip2");
    execute_command(tshock_server(), "/itemban allow 1313 vip2");
    execute_command(tshock_server(), "/itemban allow 1827 vip2");
    execute_command(tshock_server(), "/itemban allow 2270 vip2");
    execute_command(tshock_server(), "/itemban allow 2332 vip2");
    execute_command(tshock_server(), "/itemban allow 2341 vip2");
    execute_command(tshock_server(), "/itemban allow 2342 vip2");
    execute_command(tshock_server(), "/itemban allow 2365 vip2");
    execute_command(tshock_server(), "/itemban allow 2366 vip2");
    execute_command(tshock_server(), "/itemban allow 2551 vip2");
    execute_command(tshock_server(), "/itemban allow 2590 vip2");
    execute_command(tshock_server(), "/itemban allow 2608 vip2");
    execute_command(tshock_server(), "/itemban allow 2888 vip2");
    execute_command(tshock_server(), "/itemban allow 3051 vip2");
    execute_command(tshock_server(), "/itemban allow 3097 vip2");
    execute_command(tshock_server(), "/itemban allow 3282 vip2");
    execute_command(tshock_server(), "/itemban allow 3315 vip2");
    execute_command(tshock_server(), "/itemban allow 3368 vip2");
    execute_command(tshock_server(), "/itemban allow 3377 vip2");
    /*Lv3Melee*/
    execute_command(tshock_server(), "/itemban add -24");
    execute_command(tshock_server(), "/itemban add -23");
    execute_command(tshock_server(), "/itemban add -22");
    execute_command(tshock_server(), "/itemban add -21");
    execute_command(tshock_server(), "/itemban add -20");
    execute_command(tshock_server(), "/itemban add -19");
    execute_command(tshock_server(), "/itemban add 390");
    execute_command(tshock_server(), "/itemban add 406");
    execute_command(tshock_server(), "/itemban add 426");
    execute_command(tshock_server(), "/itemban add 482");
    execute_command(tshock_server(), "/itemban add 483");
    execute_command(tshock_server(), "/itemban add 484");
    execute_command(tshock_server(), "/itemban add 537");
    execute_command(tshock_server(), "/itemban add 550");
    execute_command(tshock_server(), "/itemban add 723");
    execute_command(tshock_server(), "/itemban add 1185");
    execute_command(tshock_server(), "/itemban add 1186");
    execute_command(tshock_server(), "/itemban add 1192");
    execute_command(tshock_server(), "/itemban add 1193");
    execute_command(tshock_server(), "/itemban add 1199");
    execute_command(tshock_server(), "/itemban add 1200");
    execute_command(tshock_server(), "/itemban add 1306");
    execute_command(tshock_server(), "/itemban add 1314");
    execute_command(tshock_server(), "/itemban add 3030");
    execute_command(tshock_server(), "/itemban add 3054");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow -24 近战Lv3");
    execute_command(tshock_server(), "/itemban allow -23 近战Lv3");
    execute_command(tshock_server(), "/itemban allow -22 近战Lv3");
    execute_command(tshock_server(), "/itemban allow -21 近战Lv3");
    execute_command(tshock_server(), "/itemban allow -20 近战Lv3");
    execute_command(tshock_server(), "/itemban allow -19 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 390 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 406 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 426 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 482 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 483 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 484 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 537 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 550 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 723 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1185 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1186 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1192 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1193 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1199 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1200 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1306 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1314 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3030 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3054 近战Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow -24 散人Lv3");
    execute_command(tshock_server(), "/itemban allow -23 散人Lv3");
    execute_command(tshock_server(), "/itemban allow -22 散人Lv3");
    execute_command(tshock_server(), "/itemban allow -21 散人Lv3");
    execute_command(tshock_server(), "/itemban allow -20 散人Lv3");
    execute_command(tshock_server(), "/itemban allow -19 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 390 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 406 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 426 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 482 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 483 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 484 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 537 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 550 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 723 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1185 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1186 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1192 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1193 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1199 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1200 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1306 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1314 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3030 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3054 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow -24 vip3");
    execute_command(tshock_server(), "/itemban allow -23 vip3");
    execute_command(tshock_server(), "/itemban allow -22 vip3");
    execute_command(tshock_server(), "/itemban allow -21 vip3");
    execute_command(tshock_server(), "/itemban allow -20 vip3");
    execute_command(tshock_server(), "/itemban allow -19 vip3");
    execute_command(tshock_server(), "/itemban allow 390 vip3");
    execute_command(tshock_server(), "/itemban allow 406 vip3");
    execute_command(tshock_server(), "/itemban allow 426 vip3");
    execute_command(tshock_server(), "/itemban allow 482 vip3");
    execute_command(tshock_server(), "/itemban allow 483 vip3");
    execute_command(tshock_server(), "/itemban allow 484 vip3");
    execute_command(tshock_server(), "/itemban allow 537 vip3");
    execute_command(tshock_server(), "/itemban allow 550 vip3");
    execute_command(tshock_server(), "/itemban allow 723 vip3");
    execute_command(tshock_server(), "/itemban allow 1185 vip3");
    execute_command(tshock_server(), "/itemban allow 1186 vip3");
    execute_command(tshock_server(), "/itemban allow 1192 vip3");
    execute_command(tshock_server(), "/itemban allow 1193 vip3");
    execute_command(tshock_server(), "/itemban allow 1199 vip3");
    execute_command(tshock_server(), "/itemban allow 1200 vip3");
    execute_command(tshock_server(), "/itemban allow 1306 vip3");
    execute_command(tshock_server(), "/itemban allow 1314 vip3");
    execute_command(tshock_server(), "/itemban allow 3030 vip3");
    execute_command(tshock_server(), "/itemban allow 3054 vip3");
    /*Lv3Range*/
    execute_command(tshock_server(), "/itemban add 435");
    execute_command(tshock_server(), "/itemban add 436");
    execute_command(tshock_server(), "/itemban add 481");
    execute_command(tshock_server(), "/itemban add 506");
    execute_command(tshock_server(), "/itemban add 515");
    execute_command(tshock_server(), "/itemban add 533");
    execute_command(tshock_server(), "/itemban add 679");
    execute_command(tshock_server(), "/itemban add 682");
    execute_command(tshock_server(), "/itemban add 725");
    execute_command(tshock_server(), "/itemban add 988");
    execute_command(tshock_server(), "/itemban add 1187");
    execute_command(tshock_server(), "/itemban add 1194");
    execute_command(tshock_server(), "/itemban add 1201");
    execute_command(tshock_server(), "/itemban add 1310");
    execute_command(tshock_server(), "/itemban add 1349");
    execute_command(tshock_server(), "/itemban add 3009");
    execute_command(tshock_server(), "/itemban add 3010");
    execute_command(tshock_server(), "/itemban add 3011");
    execute_command(tshock_server(), "/itemban add 3052");
    execute_command(tshock_server(), "/itemban add 3350");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 435 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 436 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 481 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 506 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 515 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 533 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 679 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 682 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 725 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 988 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1187 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1194 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1201 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1310 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1349 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3009 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3010 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3011 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3052 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3350 射手Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 435 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 436 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 481 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 506 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 515 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 533 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 679 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 682 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 725 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 988 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1187 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1194 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1201 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1310 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1349 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3009 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3010 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3011 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3052 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3350 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 435 vip3");
    execute_command(tshock_server(), "/itemban allow 436 vip3");
    execute_command(tshock_server(), "/itemban allow 481 vip3");
    execute_command(tshock_server(), "/itemban allow 506 vip3");
    execute_command(tshock_server(), "/itemban allow 515 vip3");
    execute_command(tshock_server(), "/itemban allow 533 vip3");
    execute_command(tshock_server(), "/itemban allow 679 vip3");
    execute_command(tshock_server(), "/itemban allow 682 vip3");
    execute_command(tshock_server(), "/itemban allow 725 vip3");
    execute_command(tshock_server(), "/itemban allow 988 vip3");
    execute_command(tshock_server(), "/itemban allow 1187 vip3");
    execute_command(tshock_server(), "/itemban allow 1194 vip3");
    execute_command(tshock_server(), "/itemban allow 1201 vip3");
    execute_command(tshock_server(), "/itemban allow 1310 vip3");
    execute_command(tshock_server(), "/itemban allow 1349 vip3");
    execute_command(tshock_server(), "/itemban allow 3009 vip3");
    execute_command(tshock_server(), "/itemban allow 3010 vip3");
    execute_command(tshock_server(), "/itemban allow 3011 vip3");
    execute_command(tshock_server(), "/itemban allow 3052 vip3");
    execute_command(tshock_server(), "/itemban allow 3350 vip3");
    /*Lv3Magic*/
    execute_command(tshock_server(), "/itemban add 218");
    execute_command(tshock_server(), "/itemban add 496");
    execute_command(tshock_server(), "/itemban add 514");
    execute_command(tshock_server(), "/itemban add 517");
    execute_command(tshock_server(), "/itemban add 518");
    execute_command(tshock_server(), "/itemban add 519");
    execute_command(tshock_server(), "/itemban add 929");
    execute_command(tshock_server(), "/itemban add 1157");
    execute_command(tshock_server(), "/itemban add 1244");
    execute_command(tshock_server(), "/itemban add 1336");
    execute_command(tshock_server(), "/itemban add 2535");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 218 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 496 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 514 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 517 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 518 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 519 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 929 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1157 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1244 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1336 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 2535 法师Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 218 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 496 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 514 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 517 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 518 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 519 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 929 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1157 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1244 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1336 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 2535 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 218 vip3");
    execute_command(tshock_server(), "/itemban allow 496 vip3");
    execute_command(tshock_server(), "/itemban allow 514 vip3");
    execute_command(tshock_server(), "/itemban allow 517 vip3");
    execute_command(tshock_server(), "/itemban allow 518 vip3");
    execute_command(tshock_server(), "/itemban allow 519 vip3");
    execute_command(tshock_server(), "/itemban allow 929 vip3");
    execute_command(tshock_server(), "/itemban allow 1157 vip3");
    execute_command(tshock_server(), "/itemban allow 1244 vip3");
    execute_command(tshock_server(), "/itemban allow 1336 vip3");
    execute_command(tshock_server(), "/itemban allow 2535 vip3");
    /*Lv3All*/
    execute_command(tshock_server(), "/itemban add 383");
    execute_command(tshock_server(), "/itemban add 384");
    execute_command(tshock_server(), "/itemban add 385");
    execute_command(tshock_server(), "/itemban add 386");
    execute_command(tshock_server(), "/itemban add 387");
    execute_command(tshock_server(), "/itemban add 388");
    execute_command(tshock_server(), "/itemban add 776");
    execute_command(tshock_server(), "/itemban add 777");
    execute_command(tshock_server(), "/itemban add 778");
    execute_command(tshock_server(), "/itemban add 787");
    execute_command(tshock_server(), "/itemban add 991");
    execute_command(tshock_server(), "/itemban add 992");
    execute_command(tshock_server(), "/itemban add 993");
    execute_command(tshock_server(), "/itemban add 1188");
    execute_command(tshock_server(), "/itemban add 1189");
    execute_command(tshock_server(), "/itemban add 1190");
    execute_command(tshock_server(), "/itemban add 1195");
    execute_command(tshock_server(), "/itemban add 1196");
    execute_command(tshock_server(), "/itemban add 1197");
    execute_command(tshock_server(), "/itemban add 1202");
    execute_command(tshock_server(), "/itemban add 1203");
    execute_command(tshock_server(), "/itemban add 1204");
    execute_command(tshock_server(), "/itemban add 1222");
    execute_command(tshock_server(), "/itemban add 1224");
    execute_command(tshock_server(), "/itemban add 1323");
    execute_command(tshock_server(), "/itemban add 2424");
    execute_command(tshock_server(), "/itemban add 3012");
    execute_command(tshock_server(), "/itemban add 3258");
    execute_command(tshock_server(), "/itemban add 3283");
    execute_command(tshock_server(), "/itemban add 3284");
    execute_command(tshock_server(), "/itemban add 3289");
    execute_command(tshock_server(), "/itemban add 3290");
    execute_command(tshock_server(), "/itemban add 3316");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 383 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 384 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 385 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 386 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 387 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 388 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 776 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 777 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 778 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 787 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 991 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 992 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 993 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1188 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1189 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1190 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1195 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1196 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1197 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1202 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1203 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1204 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1222 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1224 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1323 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 2424 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3012 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3258 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3283 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3284 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3289 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3290 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 3316 近战Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 383 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 384 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 385 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 386 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 387 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 388 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 776 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 777 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 778 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 787 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 991 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 992 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 993 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1188 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1189 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1190 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1195 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1196 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1197 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1202 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1203 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1204 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1222 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1224 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1323 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 2424 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3012 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3258 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3283 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3284 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3289 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3290 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 3316 射手Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 383 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 384 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 385 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 386 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 387 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 388 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 776 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 777 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 778 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 787 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 991 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 992 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 993 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1188 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1189 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1190 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1195 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1196 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1197 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1202 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1203 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1204 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1222 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1224 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1323 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 2424 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3012 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3258 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3283 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3284 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3289 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3290 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 3316 法师Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 383 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 384 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 385 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 386 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 387 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 388 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 776 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 777 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 778 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 787 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 991 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 992 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 993 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1188 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1189 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1190 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1195 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1196 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1197 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1202 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1203 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1204 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1222 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1224 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1323 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 2424 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3012 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3258 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3283 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3284 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3289 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3290 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 3316 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 383 vip3");
    execute_command(tshock_server(), "/itemban allow 384 vip3");
    execute_command(tshock_server(), "/itemban allow 385 vip3");
    execute_command(tshock_server(), "/itemban allow 386 vip3");
    execute_command(tshock_server(), "/itemban allow 387 vip3");
    execute_command(tshock_server(), "/itemban allow 388 vip3");
    execute_command(tshock_server(), "/itemban allow 776 vip3");
    execute_command(tshock_server(), "/itemban allow 777 vip3");
    execute_command(tshock_server(), "/itemban allow 778 vip3");
    execute_command(tshock_server(), "/itemban allow 787 vip3");
    execute_command(tshock_server(), "/itemban allow 991 vip3");
    execute_command(tshock_server(), "/itemban allow 992 vip3");
    execute_command(tshock_server(), "/itemban allow 993 vip3");
    execute_command(tshock_server(), "/itemban allow 1188 vip3");
    execute_command(tshock_server(), "/itemban allow 1189 vip3");
    execute_command(tshock_server(), "/itemban allow 1190 vip3");
    execute_command(tshock_server(), "/itemban allow 1195 vip3");
    execute_command(tshock_server(), "/itemban allow 1196 vip3");
    execute_command(tshock_server(), "/itemban allow 1197 vip3");
    execute_command(tshock_server(), "/itemban allow 1202 vip3");
    execute_command(tshock_server(), "/itemban allow 1203 vip3");
    execute_command(tshock_server(), "/itemban allow 1204 vip3");
    execute_command(tshock_server(), "/itemban allow 1222 vip3");
    execute_command(tshock_server(), "/itemban allow 1224 vip3");
    execute_command(tshock_server(), "/itemban allow 1323 vip3");
    execute_command(tshock_server(), "/itemban allow 2424 vip3");
    execute_command(tshock_server(), "/itemban allow 3012 vip3");
    execute_command(tshock_server(), "/itemban allow 3258 vip3");
    execute_command(tshock_server(), "/itemban allow 3283 vip3");
    execute_command(tshock_server(), "/itemban allow 3284 vip3");
    execute_command(tshock_server(), "/itemban allow 3289 vip3");
    execute_command(tshock_server(), "/itemban allow 3290 vip3");
    execute_command(tshock_server(), "/itemban allow 3316 vip3");
    /*Lv4Melee*/
    execute_command(tshock_server(), "/itemban add 368");
    execute_command(tshock_server(), "/itemban add 389");
    execute_command(tshock_server(), "/itemban add 561");
    execute_command(tshock_server(), "/itemban add 671");
    execute_command(tshock_server(), "/itemban add 672");
    execute_command(tshock_server(), "/itemban add 674");
    execute_command(tshock_server(), "/itemban add 675");
    execute_command(tshock_server(), "/itemban add 676");
    execute_command(tshock_server(), "/itemban add 756");
    execute_command(tshock_server(), "/itemban add 1226");
    execute_command(tshock_server(), "/itemban add 1227");
    execute_command(tshock_server(), "/itemban add 1228");
    execute_command(tshock_server(), "/itemban add 1233");
    execute_command(tshock_server(), "/itemban add 1259");
    execute_command(tshock_server(), "/itemban add 1297");
    execute_command(tshock_server(), "/itemban add 1324");
    execute_command(tshock_server(), "/itemban add 1327");
    execute_command(tshock_server(), "/itemban add 1571");
    execute_command(tshock_server(), "/itemban add 3018");
    execute_command(tshock_server(), "/itemban add 3211");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 368 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 389 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 561 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 671 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 672 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 674 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 675 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 676 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 756 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1226 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1227 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1228 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1233 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1259 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1297 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1324 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1327 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1571 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 3018 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 3211 近战Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 368 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 389 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 561 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 671 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 672 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 674 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 675 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 676 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 756 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1226 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1227 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1228 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1233 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1259 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1297 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1324 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1327 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1571 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3018 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3211 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 368 vip4");
    execute_command(tshock_server(), "/itemban allow 389 vip4");
    execute_command(tshock_server(), "/itemban allow 561 vip4");
    execute_command(tshock_server(), "/itemban allow 671 vip4");
    execute_command(tshock_server(), "/itemban allow 672 vip4");
    execute_command(tshock_server(), "/itemban allow 674 vip4");
    execute_command(tshock_server(), "/itemban allow 675 vip4");
    execute_command(tshock_server(), "/itemban allow 676 vip4");
    execute_command(tshock_server(), "/itemban allow 756 vip4");
    execute_command(tshock_server(), "/itemban allow 1226 vip4");
    execute_command(tshock_server(), "/itemban allow 1227 vip4");
    execute_command(tshock_server(), "/itemban allow 1228 vip4");
    execute_command(tshock_server(), "/itemban allow 1233 vip4");
    execute_command(tshock_server(), "/itemban allow 1259 vip4");
    execute_command(tshock_server(), "/itemban allow 1297 vip4");
    execute_command(tshock_server(), "/itemban allow 1324 vip4");
    execute_command(tshock_server(), "/itemban allow 1327 vip4");
    execute_command(tshock_server(), "/itemban allow 1571 vip4");
    execute_command(tshock_server(), "/itemban allow 3018 vip4");
    execute_command(tshock_server(), "/itemban allow 3211 vip4");
    /*Lv4Range*/
    execute_command(tshock_server(), "/itemban add 545");
    execute_command(tshock_server(), "/itemban add 546");
    execute_command(tshock_server(), "/itemban add 578");
    execute_command(tshock_server(), "/itemban add 758");
    execute_command(tshock_server(), "/itemban add 759");
    execute_command(tshock_server(), "/itemban add 760");
    execute_command(tshock_server(), "/itemban add 771");
    execute_command(tshock_server(), "/itemban add 1156");
    execute_command(tshock_server(), "/itemban add 1179");
    execute_command(tshock_server(), "/itemban add 1229");
    execute_command(tshock_server(), "/itemban add 1235");
    execute_command(tshock_server(), "/itemban add 1255");
    execute_command(tshock_server(), "/itemban add 1261");
    execute_command(tshock_server(), "/itemban add 1265");
    execute_command(tshock_server(), "/itemban add 1302");
    execute_command(tshock_server(), "/itemban add 1335");
    execute_command(tshock_server(), "/itemban add 1341");
    execute_command(tshock_server(), "/itemban add 1342");
    execute_command(tshock_server(), "/itemban add 1350");
    execute_command(tshock_server(), "/itemban add 1351");
    execute_command(tshock_server(), "/itemban add 1783");
    execute_command(tshock_server(), "/itemban add 1785");
    execute_command(tshock_server(), "/itemban add 1836");
    execute_command(tshock_server(), "/itemban add 2223");
    execute_command(tshock_server(), "/itemban add 3007");
    execute_command(tshock_server(), "/itemban add 3029");
    execute_command(tshock_server(), "/itemban add 3108");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 545 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 546 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 578 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 758 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 759 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 760 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 771 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1156 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1179 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1229 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1235 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1255 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1261 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1265 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1302 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1335 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1341 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1342 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1350 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1351 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1783 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1785 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1836 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 2223 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 3007 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 3029 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 3108 射手Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 545 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 546 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 578 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 758 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 759 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 760 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 771 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1156 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1179 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1229 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1235 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1255 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1261 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1265 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1302 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1335 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1341 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1342 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1350 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1351 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1783 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1785 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1836 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 2223 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3007 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3029 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3108 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 545 vip4");
    execute_command(tshock_server(), "/itemban allow 546 vip4");
    execute_command(tshock_server(), "/itemban allow 578 vip4");
    execute_command(tshock_server(), "/itemban allow 758 vip4");
    execute_command(tshock_server(), "/itemban allow 759 vip4");
    execute_command(tshock_server(), "/itemban allow 760 vip4");
    execute_command(tshock_server(), "/itemban allow 771 vip4");
    execute_command(tshock_server(), "/itemban allow 1156 vip4");
    execute_command(tshock_server(), "/itemban allow 1179 vip4");
    execute_command(tshock_server(), "/itemban allow 1229 vip4");
    execute_command(tshock_server(), "/itemban allow 1235 vip4");
    execute_command(tshock_server(), "/itemban allow 1255 vip4");
    execute_command(tshock_server(), "/itemban allow 1261 vip4");
    execute_command(tshock_server(), "/itemban allow 1265 vip4");
    execute_command(tshock_server(), "/itemban allow 1302 vip4");
    execute_command(tshock_server(), "/itemban allow 1335 vip4");
    execute_command(tshock_server(), "/itemban allow 1341 vip4");
    execute_command(tshock_server(), "/itemban allow 1342 vip4");
    execute_command(tshock_server(), "/itemban allow 1350 vip4");
    execute_command(tshock_server(), "/itemban allow 1351 vip4");
    execute_command(tshock_server(), "/itemban allow 1783 vip4");
    execute_command(tshock_server(), "/itemban allow 1785 vip4");
    execute_command(tshock_server(), "/itemban allow 1836 vip4");
    execute_command(tshock_server(), "/itemban allow 2223 vip4");
    execute_command(tshock_server(), "/itemban allow 3007 vip4");
    execute_command(tshock_server(), "/itemban allow 3029 vip4");
    execute_command(tshock_server(), "/itemban allow 3108 vip4");
    /*Lv4Magic*/
    execute_command(tshock_server(), "/itemban add 112");
    execute_command(tshock_server(), "/itemban add 422");
    execute_command(tshock_server(), "/itemban add 423");
    execute_command(tshock_server(), "/itemban add 494");
    execute_command(tshock_server(), "/itemban add 495");
    execute_command(tshock_server(), "/itemban add 683");
    execute_command(tshock_server(), "/itemban add 726");
    execute_command(tshock_server(), "/itemban add 788");
    execute_command(tshock_server(), "/itemban add 1155");
    execute_command(tshock_server(), "/itemban add 1178");
    execute_command(tshock_server(), "/itemban add 1266");
    execute_command(tshock_server(), "/itemban add 1296");
    execute_command(tshock_server(), "/itemban add 1338");
    execute_command(tshock_server(), "/itemban add 1572");
    execute_command(tshock_server(), "/itemban add 2584");
    execute_command(tshock_server(), "/itemban add 2749");
    execute_command(tshock_server(), "/itemban add 3006");
    execute_command(tshock_server(), "/itemban add 3014");
    execute_command(tshock_server(), "/itemban add 3053");
    execute_command(tshock_server(), "/itemban add 3209");
    execute_command(tshock_server(), "/itemban add 3269");
    execute_command(tshock_server(), "/itemban add 3477");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 112 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 422 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 423 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 494 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 495 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 683 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 726 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 788 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1155 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1178 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1266 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1296 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1338 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1572 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 2584 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 2749 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3006 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3014 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3053 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3209 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3269 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3477 法师Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 112 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 422 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 423 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 494 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 495 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 683 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 726 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 788 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1155 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1178 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1266 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1296 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1338 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1572 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 2584 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 2749 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3006 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3014 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3053 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3209 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3269 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3477 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 112 vip4");
    execute_command(tshock_server(), "/itemban allow 422 vip4");
    execute_command(tshock_server(), "/itemban allow 423 vip4");
    execute_command(tshock_server(), "/itemban allow 494 vip4");
    execute_command(tshock_server(), "/itemban allow 495 vip4");
    execute_command(tshock_server(), "/itemban allow 683 vip4");
    execute_command(tshock_server(), "/itemban allow 726 vip4");
    execute_command(tshock_server(), "/itemban allow 788 vip4");
    execute_command(tshock_server(), "/itemban allow 1155 vip4");
    execute_command(tshock_server(), "/itemban allow 1178 vip4");
    execute_command(tshock_server(), "/itemban allow 1266 vip4");
    execute_command(tshock_server(), "/itemban allow 1296 vip4");
    execute_command(tshock_server(), "/itemban allow 1338 vip4");
    execute_command(tshock_server(), "/itemban allow 1572 vip4");
    execute_command(tshock_server(), "/itemban allow 2584 vip4");
    execute_command(tshock_server(), "/itemban allow 2749 vip4");
    execute_command(tshock_server(), "/itemban allow 3006 vip4");
    execute_command(tshock_server(), "/itemban allow 3014 vip4");
    execute_command(tshock_server(), "/itemban allow 3053 vip4");
    execute_command(tshock_server(), "/itemban allow 3209 vip4");
    execute_command(tshock_server(), "/itemban allow 3269 vip4");
    execute_command(tshock_server(), "/itemban allow 3477 vip4");
    /*Lv4All*/
    execute_command(tshock_server(), "/itemban add 579");
    execute_command(tshock_server(), "/itemban add 996");
    execute_command(tshock_server(), "/itemban add 1230");
    execute_command(tshock_server(), "/itemban add 1231");
    execute_command(tshock_server(), "/itemban add 1232");
    execute_command(tshock_server(), "/itemban add 1234");
    execute_command(tshock_server(), "/itemban add 1262");
    execute_command(tshock_server(), "/itemban add 3286");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 579 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 996 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1230 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1231 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1232 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1234 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1262 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 3286 近战Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 579 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 996 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1230 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1231 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1232 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1234 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1262 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 3286 射手Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 579 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 996 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1230 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1231 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1232 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1234 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1262 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 3286 法师Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 579 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 996 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1230 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1231 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1232 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1234 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1262 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 3286 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 579 vip4");
    execute_command(tshock_server(), "/itemban allow 996 vip4");
    execute_command(tshock_server(), "/itemban allow 1230 vip4");
    execute_command(tshock_server(), "/itemban allow 1231 vip4");
    execute_command(tshock_server(), "/itemban allow 1232 vip4");
    execute_command(tshock_server(), "/itemban allow 1234 vip4");
    execute_command(tshock_server(), "/itemban allow 1262 vip4");
    execute_command(tshock_server(), "/itemban allow 3286 vip4");
    /*Lv5Melee*/
    execute_command(tshock_server(), "/itemban add 757");
    execute_command(tshock_server(), "/itemban add 1122");
    execute_command(tshock_server(), "/itemban add 1513");
    execute_command(tshock_server(), "/itemban add 1569");
    execute_command(tshock_server(), "/itemban add 1826");
    execute_command(tshock_server(), "/itemban add 1928");
    execute_command(tshock_server(), "/itemban add 1947");
    execute_command(tshock_server(), "/itemban add 2331");
    execute_command(tshock_server(), "/itemban add 2611");
    execute_command(tshock_server(), "/itemban add 3013");
    execute_command(tshock_server(), "/itemban add 3106");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 757 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1122 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1513 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1569 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1826 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1928 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1947 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2331 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2611 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 3013 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 3106 近战Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 757 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1122 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1513 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1569 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1826 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1928 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1947 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2331 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2611 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3013 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3106 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 757 vip5");
    execute_command(tshock_server(), "/itemban allow 1122 vip5");
    execute_command(tshock_server(), "/itemban allow 1513 vip5");
    execute_command(tshock_server(), "/itemban allow 1569 vip5");
    execute_command(tshock_server(), "/itemban allow 1826 vip5");
    execute_command(tshock_server(), "/itemban allow 1928 vip5");
    execute_command(tshock_server(), "/itemban allow 1947 vip5");
    execute_command(tshock_server(), "/itemban allow 2331 vip5");
    execute_command(tshock_server(), "/itemban allow 2611 vip5");
    execute_command(tshock_server(), "/itemban allow 3013 vip5");
    execute_command(tshock_server(), "/itemban allow 3106 vip5");
    /*Lv5Range*/
    execute_command(tshock_server(), "/itemban add 773");
    execute_command(tshock_server(), "/itemban add 1258");
    execute_command(tshock_server(), "/itemban add 1782");
    execute_command(tshock_server(), "/itemban add 1784");
    execute_command(tshock_server(), "/itemban add 1835");
    execute_command(tshock_server(), "/itemban add 1929");
    execute_command(tshock_server(), "/itemban add 1946");
    execute_command(tshock_server(), "/itemban add 2624");
    execute_command(tshock_server(), "/itemban add 2796");
    execute_command(tshock_server(), "/itemban add 2797");
    execute_command(tshock_server(), "/itemban add 3008");
    execute_command(tshock_server(), "/itemban add 3103");
    execute_command(tshock_server(), "/itemban add 3104");
    execute_command(tshock_server(), "/itemban add 3107");
    execute_command(tshock_server(), "/itemban add 3210");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 773 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1258 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1782 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1784 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1835 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1929 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1946 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 2624 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 2796 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 2797 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3008 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3103 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3104 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3107 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3210 射手Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 773 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1258 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1782 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1784 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1835 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1929 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1946 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2624 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2796 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2797 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3008 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3103 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3104 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3107 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3210 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 773 vip5");
    execute_command(tshock_server(), "/itemban allow 1258 vip5");
    execute_command(tshock_server(), "/itemban allow 1782 vip5");
    execute_command(tshock_server(), "/itemban allow 1784 vip5");
    execute_command(tshock_server(), "/itemban allow 1835 vip5");
    execute_command(tshock_server(), "/itemban allow 1929 vip5");
    execute_command(tshock_server(), "/itemban allow 1946 vip5");
    execute_command(tshock_server(), "/itemban allow 2624 vip5");
    execute_command(tshock_server(), "/itemban allow 2796 vip5");
    execute_command(tshock_server(), "/itemban allow 2797 vip5");
    execute_command(tshock_server(), "/itemban allow 3008 vip5");
    execute_command(tshock_server(), "/itemban allow 3103 vip5");
    execute_command(tshock_server(), "/itemban allow 3104 vip5");
    execute_command(tshock_server(), "/itemban allow 3107 vip5");
    execute_command(tshock_server(), "/itemban allow 3210 vip5");
    /*Lv5Magic*/
    execute_command(tshock_server(), "/itemban add 1260");
    execute_command(tshock_server(), "/itemban add 1264");
    execute_command(tshock_server(), "/itemban add 1295");
    execute_command(tshock_server(), "/itemban add 1308");
    execute_command(tshock_server(), "/itemban add 1444");
    execute_command(tshock_server(), "/itemban add 1445");
    execute_command(tshock_server(), "/itemban add 1446");
    execute_command(tshock_server(), "/itemban add 1801");
    execute_command(tshock_server(), "/itemban add 1802");
    execute_command(tshock_server(), "/itemban add 1930");
    execute_command(tshock_server(), "/itemban add 1931");
    execute_command(tshock_server(), "/itemban add 2188");
    execute_command(tshock_server(), "/itemban add 2621");
    execute_command(tshock_server(), "/itemban add 2622");
    execute_command(tshock_server(), "/itemban add 2623");
    execute_command(tshock_server(), "/itemban add 2750");
    execute_command(tshock_server(), "/itemban add 3249");
    execute_command(tshock_server(), "/itemban add 3569");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1260 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1264 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1295 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1308 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1444 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1445 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1446 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1801 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1802 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1930 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1931 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2188 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2621 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2622 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2623 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2750 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 3249 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 3569 法师Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1260 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1264 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1295 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1308 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1444 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1445 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1446 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1801 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1802 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1930 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1931 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2188 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2621 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2622 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2623 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2750 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3249 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3569 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1260 vip5");
    execute_command(tshock_server(), "/itemban allow 1264 vip5");
    execute_command(tshock_server(), "/itemban allow 1295 vip5");
    execute_command(tshock_server(), "/itemban allow 1308 vip5");
    execute_command(tshock_server(), "/itemban allow 1444 vip5");
    execute_command(tshock_server(), "/itemban allow 1445 vip5");
    execute_command(tshock_server(), "/itemban allow 1446 vip5");
    execute_command(tshock_server(), "/itemban allow 1801 vip5");
    execute_command(tshock_server(), "/itemban allow 1802 vip5");
    execute_command(tshock_server(), "/itemban allow 1930 vip5");
    execute_command(tshock_server(), "/itemban allow 1931 vip5");
    execute_command(tshock_server(), "/itemban allow 2188 vip5");
    execute_command(tshock_server(), "/itemban allow 2621 vip5");
    execute_command(tshock_server(), "/itemban allow 2622 vip5");
    execute_command(tshock_server(), "/itemban allow 2623 vip5");
    execute_command(tshock_server(), "/itemban allow 2750 vip5");
    execute_command(tshock_server(), "/itemban allow 3249 vip5");
    execute_command(tshock_server(), "/itemban allow 3569 vip5");
    /*Lv5All*/
    execute_command(tshock_server(), "/itemban add 1305");
    execute_command(tshock_server(), "/itemban add 1506");
    execute_command(tshock_server(), "/itemban add 1507");
    execute_command(tshock_server(), "/itemban add 2176");
    execute_command(tshock_server(), "/itemban add 3287");
    execute_command(tshock_server(), "/itemban add 3288");
    execute_command(tshock_server(), "/itemban add 3291");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1305 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1506 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1507 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2176 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 3287 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 3288 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 3291 近战Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1305 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1506 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1507 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 2176 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3287 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3288 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 3291 射手Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1305 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1506 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1507 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2176 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 3287 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 3288 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 3291 法师Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1305 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1506 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1507 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2176 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3287 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3288 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 3291 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1305 vip5");
    execute_command(tshock_server(), "/itemban allow 1506 vip5");
    execute_command(tshock_server(), "/itemban allow 1507 vip5");
    execute_command(tshock_server(), "/itemban allow 2176 vip5");
    execute_command(tshock_server(), "/itemban allow 3287 vip5");
    execute_command(tshock_server(), "/itemban allow 3288 vip5");
    execute_command(tshock_server(), "/itemban allow 3291 vip5");
    /*Lv6Melee*/
    execute_command(tshock_server(), "/itemban add 2880");
    execute_command(tshock_server(), "/itemban add 3063");
    execute_command(tshock_server(), "/itemban add 3065");
    execute_command(tshock_server(), "/itemban add 3098");
    execute_command(tshock_server(), "/itemban add 3473");
    execute_command(tshock_server(), "/itemban add 3543");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2880 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3063 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3065 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3098 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3473 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3543 近战Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2880 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3063 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3065 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3098 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3473 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3543 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2880 vip6");
    execute_command(tshock_server(), "/itemban allow 3063 vip6");
    execute_command(tshock_server(), "/itemban allow 3065 vip6");
    execute_command(tshock_server(), "/itemban allow 3098 vip6");
    execute_command(tshock_server(), "/itemban allow 3473 vip6");
    execute_command(tshock_server(), "/itemban allow 3543 vip6");
    /*Lv6Range*/
    execute_command(tshock_server(), "/itemban add 1254");
    execute_command(tshock_server(), "/itemban add 1553");
    execute_command(tshock_server(), "/itemban add 3475");
    execute_command(tshock_server(), "/itemban add 3546");
    execute_command(tshock_server(), "/itemban add 3549");
    execute_command(tshock_server(), "/itemban add 3567");
    execute_command(tshock_server(), "/itemban add 3568");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1254 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 1553 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3475 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3546 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3549 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3567 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3568 射手Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1254 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 1553 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3475 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3546 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3549 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3567 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3568 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1254 vip6");
    execute_command(tshock_server(), "/itemban allow 1553 vip6");
    execute_command(tshock_server(), "/itemban allow 3475 vip6");
    execute_command(tshock_server(), "/itemban allow 3546 vip6");
    execute_command(tshock_server(), "/itemban allow 3549 vip6");
    execute_command(tshock_server(), "/itemban allow 3567 vip6");
    execute_command(tshock_server(), "/itemban allow 3568 vip6");
    /*Lv6Magic*/
    execute_command(tshock_server(), "/itemban add 2795");
    execute_command(tshock_server(), "/itemban add 2882");
    execute_command(tshock_server(), "/itemban add 3105");
    execute_command(tshock_server(), "/itemban add 3474");
    execute_command(tshock_server(), "/itemban add 3476");
    execute_command(tshock_server(), "/itemban add 3531");
    execute_command(tshock_server(), "/itemban add 3541");
    execute_command(tshock_server(), "/itemban add 3542");
    execute_command(tshock_server(), "/itemban add 3570");
    execute_command(tshock_server(), "/itemban add 3571");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2795 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2882 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3105 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3474 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3476 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3531 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3541 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3542 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3570 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3571 法师Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2795 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2882 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3105 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3474 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3476 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3531 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3541 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3542 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3570 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3571 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2795 vip6");
    execute_command(tshock_server(), "/itemban allow 2882 vip6");
    execute_command(tshock_server(), "/itemban allow 3105 vip6");
    execute_command(tshock_server(), "/itemban allow 3474 vip6");
    execute_command(tshock_server(), "/itemban allow 3476 vip6");
    execute_command(tshock_server(), "/itemban allow 3531 vip6");
    execute_command(tshock_server(), "/itemban allow 3541 vip6");
    execute_command(tshock_server(), "/itemban allow 3542 vip6");
    execute_command(tshock_server(), "/itemban allow 3570 vip6");
    execute_command(tshock_server(), "/itemban allow 3571 vip6");
    /*Lv6All*/
    execute_command(tshock_server(), "/itemban add 1294");
    execute_command(tshock_server(), "/itemban add 2776");
    execute_command(tshock_server(), "/itemban add 2781");
    execute_command(tshock_server(), "/itemban add 2786");
    execute_command(tshock_server(), "/itemban add 2798");
    execute_command(tshock_server(), "/itemban add 3292");
    execute_command(tshock_server(), "/itemban add 3389");
    execute_command(tshock_server(), "/itemban add 3466");
    execute_command(tshock_server(), "/itemban add 3522");
    execute_command(tshock_server(), "/itemban add 3523");
    execute_command(tshock_server(), "/itemban add 3524");
    execute_command(tshock_server(), "/itemban add 3525");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2776 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2781 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2786 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2798 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3292 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3389 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3466 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3522 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3523 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3524 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 3525 近战Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2776 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2781 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2786 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2798 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3292 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3389 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3466 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3522 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3523 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3524 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 3525 射手Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2776 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2781 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2786 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2798 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3292 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3389 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3466 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3522 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3523 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3524 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 3525 法师Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2776 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2781 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2786 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2798 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3292 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3389 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3466 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3522 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3523 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3524 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 3525 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 vip6");
    execute_command(tshock_server(), "/itemban allow 2776 vip6");
    execute_command(tshock_server(), "/itemban allow 2781 vip6");
    execute_command(tshock_server(), "/itemban allow 2786 vip6");
    execute_command(tshock_server(), "/itemban allow 2798 vip6");
    execute_command(tshock_server(), "/itemban allow 3292 vip6");
    execute_command(tshock_server(), "/itemban allow 3389 vip6");
    execute_command(tshock_server(), "/itemban allow 3466 vip6");
    execute_command(tshock_server(), "/itemban allow 3522 vip6");
    execute_command(tshock_server(), "/itemban allow 3523 vip6");
    execute_command(tshock_server(), "/itemban allow 3524 vip6");
    execute_command(tshock_server(), "/itemban allow 3525 vip6");
	/*default*/
    //execute_command(tshock_server(), "/itemban add 1");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 1 default");
	/*Lv1*/
    //execute_command(tshock_server(), "/itemban add 4");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 4 Lv1");
    /*Lv2*/
    //execute_command(tshock_server(), "/itemban add 98");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 98 Lv2");
    /*Lv3Melee*/
    execute_command(tshock_server(), "/itemban add 372");
    execute_command(tshock_server(), "/itemban add 377");
    execute_command(tshock_server(), "/itemban add 401");
    execute_command(tshock_server(), "/itemban add 1205");
    execute_command(tshock_server(), "/itemban add 1210");
    execute_command(tshock_server(), "/itemban add 1215");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 372 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 377 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 401 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1205 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1210 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1215 近战Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 372 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 377 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 401 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1205 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1210 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1215 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 372 vip3");
    execute_command(tshock_server(), "/itemban allow 377 vip3");
    execute_command(tshock_server(), "/itemban allow 401 vip3");
    execute_command(tshock_server(), "/itemban allow 1205 vip3");
    execute_command(tshock_server(), "/itemban allow 1210 vip3");
    execute_command(tshock_server(), "/itemban allow 1215 vip3");
    /*Lv3Range*/
    execute_command(tshock_server(), "/itemban add 373");
    execute_command(tshock_server(), "/itemban add 378");
    execute_command(tshock_server(), "/itemban add 402");
    execute_command(tshock_server(), "/itemban add 1206");
    execute_command(tshock_server(), "/itemban add 1211");
    execute_command(tshock_server(), "/itemban add 1216");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 373 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 378 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 402 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1206 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1211 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1216 射手Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 373 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 378 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 402 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1206 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1211 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1216 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 373 vip3");
    execute_command(tshock_server(), "/itemban allow 378 vip3");
    execute_command(tshock_server(), "/itemban allow 402 vip3");
    execute_command(tshock_server(), "/itemban allow 1206 vip3");
    execute_command(tshock_server(), "/itemban allow 1211 vip3");
    execute_command(tshock_server(), "/itemban allow 1216 vip3");
    /*Lv3Magic*/
    execute_command(tshock_server(), "/itemban add 371");
    execute_command(tshock_server(), "/itemban add 376");
    execute_command(tshock_server(), "/itemban add 400");
    execute_command(tshock_server(), "/itemban add 1207");
    execute_command(tshock_server(), "/itemban add 1212");
    execute_command(tshock_server(), "/itemban add 1217");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 371 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 376 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 400 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1207 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1212 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1217 法师Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 371 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 376 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 400 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1207 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1212 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1217 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 371 vip3");
    execute_command(tshock_server(), "/itemban allow 376 vip3");
    execute_command(tshock_server(), "/itemban allow 400 vip3");
    execute_command(tshock_server(), "/itemban allow 1207 vip3");
    execute_command(tshock_server(), "/itemban allow 1212 vip3");
    execute_command(tshock_server(), "/itemban allow 1217 vip3");
    /*Lv3All*/
    execute_command(tshock_server(), "/itemban add 374");
    execute_command(tshock_server(), "/itemban add 375");
    execute_command(tshock_server(), "/itemban add 379");
    execute_command(tshock_server(), "/itemban add 380");
    execute_command(tshock_server(), "/itemban add 403");
    execute_command(tshock_server(), "/itemban add 404");
    execute_command(tshock_server(), "/itemban add 1208");
    execute_command(tshock_server(), "/itemban add 1209");
    execute_command(tshock_server(), "/itemban add 1213");
    execute_command(tshock_server(), "/itemban add 1214");
    execute_command(tshock_server(), "/itemban add 1218");
    execute_command(tshock_server(), "/itemban add 1219");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 374 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 375 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 379 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 380 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 403 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 404 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1208 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1209 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1213 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1214 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1218 近战Lv3");
    execute_command(tshock_server(), "/itemban allow 1219 近战Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 374 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 375 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 379 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 380 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 403 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 404 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1208 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1209 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1213 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1214 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1218 射手Lv3");
    execute_command(tshock_server(), "/itemban allow 1219 射手Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 374 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 375 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 379 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 380 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 403 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 404 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1208 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1209 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1213 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1214 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1218 法师Lv3");
    execute_command(tshock_server(), "/itemban allow 1219 法师Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 374 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 375 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 379 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 380 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 403 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 404 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1208 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1209 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1213 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1214 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1218 散人Lv3");
    execute_command(tshock_server(), "/itemban allow 1219 散人Lv3");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 374 vip3");
    execute_command(tshock_server(), "/itemban allow 375 vip3");
    execute_command(tshock_server(), "/itemban allow 379 vip3");
    execute_command(tshock_server(), "/itemban allow 380 vip3");
    execute_command(tshock_server(), "/itemban allow 403 vip3");
    execute_command(tshock_server(), "/itemban allow 404 vip3");
    execute_command(tshock_server(), "/itemban allow 1208 vip3");
    execute_command(tshock_server(), "/itemban allow 1209 vip3");
    execute_command(tshock_server(), "/itemban allow 1213 vip3");
    execute_command(tshock_server(), "/itemban allow 1214 vip3");
    execute_command(tshock_server(), "/itemban allow 1218 vip3");
    execute_command(tshock_server(), "/itemban allow 1219 vip3");
    /*Lv4Melee*/
    execute_command(tshock_server(), "/itemban add 559");
    execute_command(tshock_server(), "/itemban add 1001");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 559 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1001 近战Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 559 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1001 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 559 vip4");
    execute_command(tshock_server(), "/itemban allow 1001 vip4");
    /*Lv4Range*/
    execute_command(tshock_server(), "/itemban add 553");
    execute_command(tshock_server(), "/itemban add 1002");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 553 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1002 射手Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 553 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1002 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 553 vip4");
    execute_command(tshock_server(), "/itemban allow 1002 vip4");
    /*Lv4Magic*/
    execute_command(tshock_server(), "/itemban add 558");
    execute_command(tshock_server(), "/itemban add 1003");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 558 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1003 法师Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 558 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1003 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 558 vip4");
    execute_command(tshock_server(), "/itemban allow 1003 vip4");
    /*Lv4All*/
    execute_command(tshock_server(), "/itemban add 551");
    execute_command(tshock_server(), "/itemban add 552");
    execute_command(tshock_server(), "/itemban add 684");
    execute_command(tshock_server(), "/itemban add 685");
    execute_command(tshock_server(), "/itemban add 686");
    execute_command(tshock_server(), "/itemban add 1004");
    execute_command(tshock_server(), "/itemban add 1005");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 551 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 552 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 684 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 685 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 686 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1004 近战Lv4");
    execute_command(tshock_server(), "/itemban allow 1005 近战Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 551 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 552 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 684 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 685 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 686 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1004 射手Lv4");
    execute_command(tshock_server(), "/itemban allow 1005 射手Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 551 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 552 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 684 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 685 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 686 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1004 法师Lv4");
    execute_command(tshock_server(), "/itemban allow 1005 法师Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 551 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 552 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 684 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 685 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 686 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1004 散人Lv4");
    execute_command(tshock_server(), "/itemban allow 1005 散人Lv4");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 551 vip4");
    execute_command(tshock_server(), "/itemban allow 552 vip4");
    execute_command(tshock_server(), "/itemban allow 684 vip4");
    execute_command(tshock_server(), "/itemban allow 685 vip4");
    execute_command(tshock_server(), "/itemban allow 686 vip4");
    execute_command(tshock_server(), "/itemban allow 1004 vip4");
    execute_command(tshock_server(), "/itemban allow 1005 vip4");
    /*Lv5Melee*/
    execute_command(tshock_server(), "/itemban add 1316");
    execute_command(tshock_server(), "/itemban add 1317");
    execute_command(tshock_server(), "/itemban add 1318");
    execute_command(tshock_server(), "/itemban add 2199");
    execute_command(tshock_server(), "/itemban add 2200");
    execute_command(tshock_server(), "/itemban add 2201");
    execute_command(tshock_server(), "/itemban add 2202");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1316 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1317 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 1318 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2199 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2200 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2201 近战Lv5");
    execute_command(tshock_server(), "/itemban allow 2202 近战Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1316 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1317 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1318 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2199 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2200 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2201 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2202 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1316 vip5");
    execute_command(tshock_server(), "/itemban allow 1317 vip5");
    execute_command(tshock_server(), "/itemban allow 1318 vip5");
    execute_command(tshock_server(), "/itemban allow 2199 vip5");
    execute_command(tshock_server(), "/itemban allow 2200 vip5");
    execute_command(tshock_server(), "/itemban allow 2201 vip5");
    execute_command(tshock_server(), "/itemban allow 2202 vip5");
    /*Lv5Range*/
    execute_command(tshock_server(), "/itemban add 1546");
    execute_command(tshock_server(), "/itemban add 1547");
    execute_command(tshock_server(), "/itemban add 1548");
    execute_command(tshock_server(), "/itemban add 1549");
    execute_command(tshock_server(), "/itemban add 1550");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1546 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1547 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1548 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1549 射手Lv5");
    execute_command(tshock_server(), "/itemban allow 1550 射手Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1546 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1547 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1548 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1549 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1550 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1546 vip5");
    execute_command(tshock_server(), "/itemban allow 1547 vip5");
    execute_command(tshock_server(), "/itemban allow 1548 vip5");
    execute_command(tshock_server(), "/itemban allow 1549 vip5");
    execute_command(tshock_server(), "/itemban allow 1550 vip5");
    /*Lv5Magic*/
    execute_command(tshock_server(), "/itemban add 1503");
    execute_command(tshock_server(), "/itemban add 1504");
    execute_command(tshock_server(), "/itemban add 1505");
    execute_command(tshock_server(), "/itemban add 2189");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1503 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1504 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 1505 法师Lv5");
    execute_command(tshock_server(), "/itemban allow 2189 法师Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1503 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1504 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 1505 散人Lv5");
    execute_command(tshock_server(), "/itemban allow 2189 散人Lv5");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1503 vip5");
    execute_command(tshock_server(), "/itemban allow 1504 vip5");
    execute_command(tshock_server(), "/itemban allow 1505 vip5");
    execute_command(tshock_server(), "/itemban allow 2189 vip5");
    /*Lv5All*/
    //execute_command(tshock_server(), "/itemban add 1305");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 1305 近战Lv5");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 1305 射手Lv5");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 1305 法师Lv5");
    //execute_command(tshock_server(), "");
    //execute_command(tshock_server(), "/itemban allow 1305 散人Lv5");
    /*Lv6Melee*/
    execute_command(tshock_server(), "/itemban add 2763");
    execute_command(tshock_server(), "/itemban add 2764");
    execute_command(tshock_server(), "/itemban add 2765");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2763 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2764 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 2765 近战Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2763 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2764 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2765 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2763 vip6");
    execute_command(tshock_server(), "/itemban allow 2764 vip6");
    execute_command(tshock_server(), "/itemban allow 2765 vip6");
    /*Lv6Range*/
    execute_command(tshock_server(), "/itemban add 2757");
    execute_command(tshock_server(), "/itemban add 2758");
    execute_command(tshock_server(), "/itemban add 2759");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2757 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2758 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 2759 射手Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2757 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2758 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2759 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2757 vip6");
    execute_command(tshock_server(), "/itemban allow 2758 vip6");
    execute_command(tshock_server(), "/itemban allow 2759 vip6");
    /*Lv6Magic*/
    execute_command(tshock_server(), "/itemban add 2760");
    execute_command(tshock_server(), "/itemban add 2761");
    execute_command(tshock_server(), "/itemban add 2762");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2760 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2761 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 2762 法师Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2760 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2761 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 2762 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 2760 vip6");
    execute_command(tshock_server(), "/itemban allow 2761 vip6");
    execute_command(tshock_server(), "/itemban allow 2762 vip6");
    /*Lv6All*/
    execute_command(tshock_server(), "/itemban add 1294");
    execute_command(tshock_server(), "/itemban add 1294");
    execute_command(tshock_server(), "/itemban add 1294");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 近战Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 近战Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 射手Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 射手Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 法师Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 法师Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 散人Lv6");
    execute_command(tshock_server(), "/itemban allow 1294 散人Lv6");
    execute_command(tshock_server(), "");
    execute_command(tshock_server(), "/itemban allow 1294 vip6");
    execute_command(tshock_server(), "/itemban allow 1294 vip6");
    execute_command(tshock_server(), "/itemban allow 1294 vip6");
});